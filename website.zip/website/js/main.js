'use strict';

// ============================================
// GUIDE ROBOT - Main Application
// ============================================

// ============================================
// 0. Theme Manager
// ============================================
const ThemeManager = {
  STORAGE_KEY: 'qingluan-theme',

  THEME_CONFIG: {
    dark: {
      metaColor: '#0a0a1a',
      particleColors: [[0, 240, 255], [255, 0, 255]],
      particleOpacity: [0.4, 0.24],
      connectionColor: [0, 240, 255],
      connectionOpacity: 0.12
    },
    light: {
      metaColor: '#f5f6fa',
      particleColors: [[100, 140, 210], [180, 100, 160]],
      particleOpacity: [0.15, 0.1],
      connectionColor: [100, 140, 210],
      connectionOpacity: 0.05
    },
    blue: {
      metaColor: '#060d1a',
      particleColors: [[64, 160, 255], [128, 96, 255]],
      particleOpacity: [0.38, 0.22],
      connectionColor: [64, 160, 255],
      connectionOpacity: 0.11
    },
    purple: {
      metaColor: '#100618',
      particleColors: [[160, 96, 255], [224, 64, 176]],
      particleOpacity: [0.36, 0.2],
      connectionColor: [160, 96, 255],
      connectionOpacity: 0.11
    },
    sky: {
      metaColor: '#e8f4fd',
      particleColors: [[30, 136, 229], [100, 180, 230]],
      particleOpacity: [0.16, 0.1],
      connectionColor: [30, 136, 229],
      connectionOpacity: 0.05
    },
    forest: {
      metaColor: '#0a120d',
      particleColors: [[52, 211, 153], [244, 114, 182]],
      particleOpacity: [0.36, 0.18],
      connectionColor: [52, 211, 153],
      connectionOpacity: 0.1
    },
    amber: {
      metaColor: '#1a0e08',
      particleColors: [[251, 146, 60], [244, 114, 136]],
      particleOpacity: [0.36, 0.18],
      connectionColor: [251, 146, 60],
      connectionOpacity: 0.1
    },
    graphite: {
      metaColor: '#1a1a1e',
      particleColors: [[96, 165, 250], [192, 132, 252]],
      particleOpacity: [0.3, 0.16],
      connectionColor: [96, 165, 250],
      connectionOpacity: 0.08
    },
    sakura: {
      metaColor: '#1a1018',
      particleColors: [[249, 168, 212], [232, 121, 160]],
      particleOpacity: [0.34, 0.18],
      connectionColor: [249, 168, 212],
      connectionOpacity: 0.1
    },
    aurora: {
      metaColor: '#081a18',
      particleColors: [[45, 212, 191], [129, 140, 248]],
      particleOpacity: [0.36, 0.2],
      connectionColor: [45, 212, 191],
      connectionOpacity: 0.1
    }
  },

  _current: 'dark',
  _onChangeCallbacks: [],

  init() {
    const saved = localStorage.getItem(this.STORAGE_KEY);
    if (saved && this.THEME_CONFIG[saved]) {
      this._current = saved;
    }
    this._applyToDOM(this._current);
    return this._current;
  },

  get() {
    return this._current;
  },

  getConfig() {
    return this.THEME_CONFIG[this._current];
  },

  set(name) {
    if (!this.THEME_CONFIG[name]) return;
    this._current = name;
    localStorage.setItem(this.STORAGE_KEY, name);
    this._applyToDOM(name);
    this._onChangeCallbacks.forEach(fn => fn(this.THEME_CONFIG[name]));
  },

  _applyToDOM(name) {
    document.documentElement.setAttribute('data-theme', name);
    const meta = document.getElementById('meta-theme-color');
    if (meta) {
      meta.setAttribute('content', this.THEME_CONFIG[name].metaColor);
    }
  },

  onChange(fn) {
    this._onChangeCallbacks.push(fn);
  }
};

document.addEventListener('DOMContentLoaded', () => {
  initLanguageSwitch();
  initThemeSwitcher();
  initAutoTheme();
  initParticleCanvas();
  ThemeManager.onChange((config) => {
    if (window.__particleReload) window.__particleReload(config);
  });
  initMobileNav();
  initScrollAnimations();
  initNavScroll();
  initTypewriter();
  initSmoothScroll();
  initParallax();
  initAnimatedCounters();
  loadMarkdownContent();
  initScrollProgress();
  initBackToTop();
  initCTABar();
  initSearch();
  initFAQ();
  initAccessibilityMode();
});

// ============================================
// Utility: wait for marked
// ============================================
function waitForMarked() {
  return new Promise((resolve) => {
    if (typeof marked !== 'undefined') {
      resolve();
      return;
    }
    const check = () => {
      if (typeof marked !== 'undefined') {
        resolve();
      } else {
        setTimeout(check, 50);
      }
    };
    check();
  });
}

// ============================================
// 1. Particle Background System
// ============================================
function initParticleCanvas() {
  const canvas = document.getElementById('particle-canvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let particles = [];
  let mouseX = -1000;
  let mouseY = -1000;
  let animId = null;

  // Read colors from current theme config
  let cfg = ThemeManager.getConfig();

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }

  window.addEventListener('resize', resize);
  resize();

  canvas.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  });

  canvas.addEventListener('mouseleave', () => {
    mouseX = -1000;
    mouseY = -1000;
  });

  // Responsive particle count
  const area = canvas.width * canvas.height;
  const count = Math.min(
    Math.max(Math.floor(area / 12000), 40),
    120
  );

  class Particle {
    constructor() { this.reset(); }
    reset() {
      this.x = Math.random() * canvas.width;
      this.y = Math.random() * canvas.height;
      this.size = Math.random() * 2 + 0.5;
      this.speedX = (Math.random() - 0.5) * 0.4;
      this.speedY = (Math.random() - 0.5) * 0.4;
      this.opacity = Math.random() * cfg.particleOpacity[0] + cfg.particleOpacity[1];
      this.type = Math.random() > 0.5 ? 0 : 1; // 0=primary, 1=secondary
    }
    update() {
      const dx = mouseX - this.x;
      const dy = mouseY - this.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 200) {
        const force = (200 - dist) / 200 * 0.3;
        this.speedX -= (dx / dist) * force * 0.1;
        this.speedY -= (dy / dist) * force * 0.1;
      }
      this.speedX *= 0.98;
      this.speedY *= 0.98;
      this.x += this.speedX;
      this.y += this.speedY;
      if (this.x < -10) this.x = canvas.width + 10;
      if (this.x > canvas.width + 10) this.x = -10;
      if (this.y < -10) this.y = canvas.height + 10;
      if (this.y > canvas.height + 10) this.y = -10;
    }
    draw() {
      const color = cfg.particleColors[this.type];
      const opacity = this.type === 0
        ? cfg.particleOpacity[0]
        : cfg.particleOpacity[1];
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${color[0]}, ${color[1]}, ${color[2]}, ${this.opacity})`;
      ctx.shadowBlur = 8;
      ctx.shadowColor = `rgba(${color[0]}, ${color[1]}, ${color[2]}, 0.2)`;
      ctx.fill();
      ctx.shadowBlur = 0;
    }
  }

  for (let i = 0; i < count; i++) {
    particles.push(new Particle());
  }

  function drawConnections() {
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 150) {
          const opacity = (1 - dist / 150) * cfg.connectionOpacity;
          const c = cfg.connectionColor;
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${opacity})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }
  }

  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => { p.update(); p.draw(); });
    drawConnections();
    animId = requestAnimationFrame(animate);
  }

  animate();

  // Expose reload for theme changes
  window.__particleReload = (newConfig) => {
    cfg = newConfig || ThemeManager.getConfig();
    particles.forEach(p => p.reset());
  };

  window.__particleCleanup = () => {
    if (animId) cancelAnimationFrame(animId);
    particles = [];
  };
}

// ============================================
// 2. Mobile Navigation
// ============================================
function initMobileNav() {
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (!toggle || !links) return;
  toggle.addEventListener('click', () => {
    links.classList.toggle('open');
  });
  links.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => links.classList.remove('open'));
  });
}

// ============================================
// 3. Scroll-triggered Animations
// ============================================
function initScrollAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    },
    { threshold: 0.08, rootMargin: '0px 0px -60px 0px' }
  );

  document.querySelectorAll(
    '.fade-in, .fade-in-left, .fade-in-right, .feature-card, .stat-card, .arch-box'
  ).forEach(el => {
    if (!el.classList.contains('fade-in') &&
        !el.classList.contains('fade-in-left') &&
        !el.classList.contains('fade-in-right')) {
      el.classList.add('fade-in');
    }
    observer.observe(el);
  });
}

// ============================================
// 4. Navbar Scroll Effect
// ============================================
function initNavScroll() {
  const nav = document.querySelector('nav');
  const links = document.querySelectorAll('.nav-links a');
  if (!nav) return;
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      window.requestAnimationFrame(() => {
        nav.classList.toggle('scrolled', window.scrollY > 50);
        updateActiveNavLink(links);
        ticking = false;
      });
      ticking = true;
    }
  });
  updateActiveNavLink(links);
}

function updateActiveNavLink(links) {
  const scrollPos = window.scrollY + 180;
  links.forEach(link => {
    const targetId = link.getAttribute('href').substring(1);
    const target = document.getElementById(targetId);
    if (target) {
      const offsetTop = target.offsetTop;
      const offsetBottom = offsetTop + target.offsetHeight;
      if (scrollPos >= offsetTop && scrollPos < offsetBottom) {
        links.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
      }
    }
  });
}

// ============================================
// 5. Typewriter Effect
// ============================================
function initTypewriter() {
  const element = document.querySelector('.hero-subtitle');
  if (!element) return;

  const text = element.textContent.trim();
  element.textContent = '';
  let index = 0;
  const speed = 35;

  // Add cursor
  const cursor = document.createElement('span');
  cursor.className = 'cursor';
  element.appendChild(cursor);

  function type() {
    if (index < text.length) {
      cursor.insertAdjacentText('beforebegin', text[index]);
      index++;
      setTimeout(type, speed);
    }
  }

  setTimeout(type, 1200);
}

// ============================================
// 6. Parallax Effect
// ============================================
function initParallax() {
  const parallaxSections = document.querySelectorAll('#about, #technology, #home-intro');
  if (parallaxSections.length === 0) return;

  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      window.requestAnimationFrame(() => {
        const scrollY = window.scrollY;
        parallaxSections.forEach(section => {
          const rect = section.getBoundingClientRect();
          if (rect.top < window.innerHeight && rect.bottom > 0) {
            const speed = 0.05;
            const yPos = (rect.top) * speed;
            section.style.setProperty('--parallax-y', `${yPos}px`);
          }
        });
        ticking = false;
      });
      ticking = true;
    }
  });
}

// ============================================
// 7. Animated Counters — numbers count up on scroll
// ============================================
// Singleton observer to avoid duplicate registrations across renderContent calls
let _counterObserver = null;
const _counterRegistry = new WeakSet();

function initAnimatedCounters() {
  const counterEls = document.querySelectorAll('.stat-number');
  if (counterEls.length === 0) return;

  // Guard: only process elements NOT yet registered (prevents re-reset on re-call)
  const freshEls = Array.from(counterEls).filter(el => !_counterRegistry.has(el));
  if (freshEls.length === 0) return;

  // Lazy-create single observer
  if (!_counterObserver) {
    _counterObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting && entry.target.dataset.counterDone !== 'true') {
            entry.target.dataset.counterDone = 'true';
            animateCounter(entry.target);
            _counterObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
  }

  freshEls.forEach(el => {
    const fullText = el.textContent.trim();
    const match = fullText.match(/^([\d.]+)(.*)$/);
    if (!match) return;

    // Tag IMMEDIATELY to prevent re-processing on subsequent initAnimatedCounters() calls
    _counterRegistry.add(el);

    el.dataset.target = match[1];
    el.dataset.unit = match[2];
    // Preserve unit in initial display: "0Hz", "0m/s", etc.
    el.textContent = '0' + match[2];

    _counterObserver.observe(el);
  });
}

function animateCounter(el) {
  const target = parseFloat(el.dataset.target);
  const unit = el.dataset.unit || '';
  if (isNaN(target)) return;

  const duration = 1500;
  const startTime = performance.now();
  let lastValue = -1;

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const current = target % 1 === 0
      ? Math.round(target * eased)
      : parseFloat((target * eased).toFixed(1));

    // Only update DOM if value changed (reduces layout thrashing)
    if (current !== lastValue) {
      lastValue = current;
      el.textContent = (target % 1 === 0 ? current : current.toFixed(1)) + unit;
    }

    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      // Ensure final frame shows exact target
      el.textContent = target + unit;
    }
  }

  requestAnimationFrame(update);
}

// ============================================
// 8. Markdown Content Loader
// ============================================
async function loadMarkdownContent(lang) {
  const currentLang = lang || (isEn() ? 'en' : 'zh');
  await waitForMarked();

  const sections = document.querySelectorAll('[data-md]');
  const mdKeyMap = { 'home-intro': 'md-home', 'about': 'md-about', 'products': 'md-products', 'technology': 'md-technology', 'contact': 'md-contact' };

  sections.forEach(section => {
    const mdPath = section.getAttribute('data-md');
    if (!mdPath) return;
    const key = mdKeyMap[section.id];

    // Always clear any existing rendered content first
    const container = section.querySelector('.section-inner');
    if (container) {
      const old = container.querySelector('.md-content');
      if (old) old.remove();
      const err = container.querySelector('.md-error');
      if (err) err.remove();
      const load = container.querySelector('.loading');
      if (load) load.remove();
    }

    section.dataset.mdLang = currentLang;

    // For English: use I18N dictionary (external .md files are Chinese-only)
    if (currentLang === 'en') {
      const mdContent = key && I18N.en && I18N.en[key] ? I18N.en[key] : null;
      if (mdContent) {
        try {
          const html = marked.parse(mdContent, { breaks: true, gfm: true });
          renderContent(section, html);
        } catch (e) {
          console.error('Markdown parse error:', e);
          showError(section, 'Failed to render English content.');
        }
      } else {
        showError(section, 'English content not available.');
      }
      return;
    }

    // For Chinese: try external .md file, fallback to dictionary
    showLoading(section);
    fetch(mdPath)
      .then(response => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return response.text();
      })
      .then(markdown => {
        const html = marked.parse(markdown, { breaks: true, gfm: true });
        renderContent(section, html);
      })
      .catch(err => {
        console.warn('Failed to load', mdPath, err.message);
        const mdContent = key && I18N.zh && I18N.zh[key] ? I18N.zh[key] : null;
        if (mdContent) {
          try {
            const html = marked.parse(mdContent, { breaks: true, gfm: true });
            renderContent(section, html);
          } catch (e) {
            showError(section, '内容渲染失败');
          }
        } else {
          showError(section, '内容加载失败');
        }
      });
  });
}

// Reload all markdown sections — always forces re-render
function reloadMarkdownForLanguage(lang) {
  // Force clear all markdown sections
  document.querySelectorAll('[data-md]').forEach(section => {
    const container = section.querySelector('.section-inner');
    if (container) {
      const md = container.querySelector('.md-content');
      if (md) md.remove();
      const err = container.querySelector('.md-error');
      if (err) err.remove();
      const load = container.querySelector('.loading');
      if (load) load.remove();
    }
    delete section.dataset.mdLang;
  });
  loadMarkdownContent(lang);
}

function showLoading(section) {
  let container = section.querySelector('.section-inner');
  if (!container) {
    container = document.createElement('div');
    container.className = 'section-inner';
    section.appendChild(container);
  }

  if (!container.querySelector('.md-content')) {
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'loading';
    loadingDiv.innerHTML = `
      <div class="loading-spinner"></div>
      <div class="loading-text">LOADING_SYSTEM...</div>
    `;
    container.appendChild(loadingDiv);
  }
}

function renderContent(section, html) {
  let container = section.querySelector('.section-inner');

  // Remove loading state
  const loadingEl = container.querySelector('.loading');
  if (loadingEl) loadingEl.remove();

  const contentDiv = document.createElement('div');
  contentDiv.className = 'md-content fade-in';
  contentDiv.innerHTML = html;

  // Build rich content from markdown
  buildRichContent(section, contentDiv);

  container.appendChild(contentDiv);

  // Trigger animation and observe children
  requestAnimationFrame(() => {
    contentDiv.classList.add('visible');
    contentDiv.querySelectorAll('.feature-card, .stat-card, .arch-box, .md-content > *').forEach(el => {
      if (!el.classList.contains('feature-card') &&
          !el.classList.contains('stat-card') &&
          !el.classList.contains('arch-box')) {
        el.classList.add('fade-in');
      }
    });
    // Re-init scroll animations on new content
    initScrollAnimations();
    initAnimatedCounters();
  });
}

function showError(section, message) {
  let container = section.querySelector('.section-inner');
  const loadingEl = container.querySelector('.loading');
  if (loadingEl) loadingEl.remove();
  const errorDiv = document.createElement('div');
  errorDiv.className = 'md-error fade-in';
  errorDiv.innerHTML = `
    <div class="error-icon">⚠</div>
    <div class="error-text">${escapeHtml(message)}</div>
  `;
  container.appendChild(errorDiv);
  requestAnimationFrame(() => errorDiv.classList.add('visible'));
}

// ============================================
// 9. Rich Content Builder
// ============================================
function buildRichContent(section, contentDiv) {
  const id = section.id;

  // Wrap tables in responsive containers
  contentDiv.querySelectorAll('table').forEach(table => {
    const wrapper = document.createElement('div');
    wrapper.style.overflowX = 'auto';
    table.parentNode.insertBefore(wrapper, table);
    wrapper.appendChild(table);
  });

  // Insert feature grid for home-intro/about sections
  if (id === 'about' || id === 'home-intro') {
    // Count how many h3s have card-like content
    if (id === 'about') {
      const firstH3 = contentDiv.querySelector('h3');
      if (firstH3) {
        const grid = createFeatureGrid();
        firstH3.insertAdjacentElement('beforebegin', grid);
      }
    }
  }

  // Insert stats for home-intro section
  if (id === 'home-intro') {
    const blockquote = contentDiv.querySelector('blockquote');
    const statsGrid = createStatsGrid();
    if (blockquote) {
      blockquote.insertAdjacentElement('beforebegin', statsGrid);
    } else {
      contentDiv.appendChild(statsGrid);
    }
  }

  // Insert architecture diagram for technology section
  if (id === 'technology') {
    const firstH3 = contentDiv.querySelector('h3');
    if (firstH3) {
      const archDiagram = createArchitectureDiagram();
      firstH3.insertAdjacentElement('beforebegin', archDiagram);
    }
  }
}

function createFeatureGrid() {
  const en = document.documentElement.getAttribute('lang') === 'en';
  const features = en ? [
    { icon: '🔮', title: 'Multi-Sensor Fusion', desc: 'MPU6050 IMU, ultrasonic ranging, FOMO vision detection — multi-dimensional environmental perception' },
    { icon: '🧠', title: 'AI Path Planning', desc: 'A* global path planning + artificial potential field local avoidance, 10Hz real-time replanning for dynamic environments' },
    { icon: '⚙️', title: 'Precision Motion Control', desc: 'Cascade PID + 5-bar inverse kinematics + BLDC FOC, 50-200Hz high-frequency control' },
    { icon: '🗣️', title: 'Natural Interaction', desc: 'Admittance control force-following + offline AI voice recognition + TTS feedback, multi-modal HCI' }
  ] : [
    { icon: '🔮', title: '多传感融合', desc: 'MPU6050姿态传感、超声波测距、视觉FOMO检测，多维度环境感知' },
    { icon: '🧠', title: 'AI 路径规划', desc: 'A*全局路径规划 + 人工势场局部避障，10Hz实时重规划应对动态环境' },
    { icon: '⚙️', title: '精密运动控制', desc: '串级PID + 5连杆逆运动学 + BLDC FOC，50-200Hz高频控制' },
    { icon: '🗣️', title: '自然交互', desc: '导纳控制力控随行 + 离线AI语音识别 + TTS播报，多维人机交互' }
  ];
  const grid = document.createElement('div');
  grid.className = 'feature-grid';
  features.forEach(f => {
    const card = document.createElement('div');
    card.className = 'feature-card';
    card.innerHTML = `
      <div class="icon">${f.icon}</div>
      <h3>${f.title}</h3>
      <p>${f.desc}</p>
    `;
    grid.appendChild(card);
  });
  return grid;
}

function createStatsGrid() {
  const en = document.documentElement.getAttribute('lang') === 'en';
  const stats = en ? [
    { number: '10', unit: 'Hz', label: 'System Frame Rate' },
    { number: '200', unit: 'Hz', label: 'Control Frequency' },
    { number: '92', unit: '%', label: 'Recognition Rate' },
    { number: '0.5', unit: 'm/s', label: 'Max Speed' }
  ] : [
    { number: '10', unit: 'Hz', label: '系统帧率' },
    { number: '200', unit: 'Hz', label: '控制频率' },
    { number: '92', unit: '%', label: '语音识别率' },
    { number: '0.5', unit: 'm/s', label: '最大速度' }
  ];
  const grid = document.createElement('div');
  grid.className = 'stats-grid';
  stats.forEach(s => {
    const card = document.createElement('div');
    card.className = 'stat-card';
    card.innerHTML = `
      <div class="stat-number">${s.number}${s.unit}</div>
      <div class="stat-label">${s.label}</div>
    `;
    grid.appendChild(card);
  });
  return grid;
}

function createArchitectureDiagram() {
  const en = document.documentElement.getAttribute('lang') === 'en';
  const div = document.createElement('div');
  div.className = 'arch-diagram fade-in';
  div.innerHTML = en ? `
    <div class="arch-box openmv">
      <div class="label">PERCEPTION & PLANNING</div>
      <div class="title">OpenMV H7 Plus</div>
      <div class="sub">Cortex-M7 @ 480MHz · 32MB SDRAM</div>
      <div class="sub">FOMO Vision → A* Planning → Ultrasonic → Avoidance</div>
    </div>
    <div class="arch-arrow">⬇ UART @ 921600 bps ⬇</div>
    <div class="arch-box esp32">
      <div class="label">MOTION CONTROL & INTERACTION</div>
      <div class="title">ESP32-S3</div>
      <div class="sub">Xtensa LX7 @ 240MHz · Dual-Core</div>
      <div class="sub">Cascade PID → Inverse Kinematics → Servo/Motor → ASR/TTS</div>
    </div>
  ` : `
    <div class="arch-box openmv">
      <div class="label">PERCEPTION & PLANNING</div>
      <div class="title">OpenMV H7 Plus</div>
      <div class="sub">Cortex-M7 @ 480MHz · 32MB SDRAM</div>
      <div class="sub">FOMO视觉推理 → A*路径规划 → 超声测距 → 势场避障</div>
    </div>
    <div class="arch-arrow">⬇ UART @ 921600 bps ⬇</div>
    <div class="arch-box esp32">
      <div class="label">MOTION CONTROL & INTERACTION</div>
      <div class="title">ESP32-S3</div>
      <div class="sub">Xtensa LX7 @ 240MHz · 双核</div>
      <div class="sub">串级PID → 逆运动学 → 舵机/电机 → ASR/TTS</div>
    </div>
  `;
  return div;
}

// ============================================
// 10. Smooth Scroll
// ============================================
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (e) => {
      const targetId = anchor.getAttribute('href').substring(1);
      const target = document.getElementById(targetId);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
}

// ============================================
// 11. Platform: Smart Parameter Configurator
// ============================================
function initConfigurator() {
  const ageSlider = document.getElementById('config-age');
  const heightSlider = document.getElementById('config-height');
  const sceneSelect = document.getElementById('config-scene');
  const visionSelect = document.getElementById('config-vision');
  const citySelect = document.getElementById('config-city');
  const freqSelect = document.getElementById('config-frequency');
  const incomeSelect = document.getElementById('config-income');
  const genderRadios = document.querySelectorAll('input[name="gender"]');

  if (!ageSlider || !heightSlider || !sceneSelect) return;

  function readParams() {
    return {
      age: parseInt(ageSlider.value),
      height: parseInt(heightSlider.value),
      gender: document.querySelector('input[name="gender"]:checked')?.value || 'male',
      scene: sceneSelect.value,
      vision: visionSelect ? visionSelect.value : 'blind',
      city: citySelect ? citySelect.value : 'tier1',
      frequency: freqSelect ? freqSelect.value : 'daily',
      income: incomeSelect ? incomeSelect.value : ''
    };
  }

  function updateOutput() {
    const p = readParams();

    // Display values
    document.getElementById('config-age-val').textContent = `${p.age} ${isEn() ? 'yr' : '岁'}`;
    document.getElementById('config-height-val').textContent = `${p.height} cm`;

    const recs = computeRecommendations(p);
    applyRecommendations(recs);
  }

  function computeRecommendations(p) {
    const { age, height, gender, scene, vision, city, frequency, income } = p;
    const recs = {};

    // ── Body size: based on height ──
    if (height < 155) recs.size = i18n('rec-size-small');
    else if (height < 175) recs.size = i18n('rec-size-medium');
    else recs.size = i18n('rec-size-large');

    // ── Rope length: based on height ──
    if (height < 155) recs.rope = '110cm';
    else if (height < 175) recs.rope = '120cm';
    else recs.rope = '135cm';

    // ── Voice mode: based on gender, age, vision ──
    const g = gender === 'female' ? 'female' : 'male';
    if (age > 60) recs.voice = i18n('rec-voice-gentle-' + g);
    else if (vision === 'blind') recs.voice = i18n('rec-voice-hd-' + g);
    else recs.voice = i18n('rec-voice-standard-' + g);

    // ── Speed: based on age, vision, scene ──
    if (age > 70 || vision === 'blind') recs.speed = '0.3 m/s';
    else if (age > 55) recs.speed = '0.4 m/s';
    else if (scene === 'outdoor') recs.speed = '0.5 m/s';
    else if (scene === 'indoor') recs.speed = '0.3 m/s';
    else recs.speed = '0.4 m/s';

    // ── Obstacle sensitivity: based on scene, vision, city ──
    let senseScore = 0;
    if (scene === 'urban') senseScore += 2;
    if (vision === 'blind') senseScore += 2;
    else if (vision === 'low') senseScore += 1;
    if (city === 'tier1') senseScore += 1;
    recs.sense = i18n(senseScore >= 3 ? 'rec-sense-ultra' : senseScore >= 2 ? 'rec-sense-high' : senseScore >= 1 ? 'rec-sense-medium' : 'rec-sense-standard');

    // ── Battery: based on scene, frequency ──
    if (frequency === 'daily' && scene === 'urban') recs.battery = '8000mAh';
    else if (frequency === 'daily') recs.battery = '6000mAh';
    else if (scene === 'outdoor') recs.battery = '8000mAh';
    else if (frequency === 'occasional') recs.battery = '4000mAh';
    else recs.battery = '5000mAh';

    // ── Product tier: based on income, city, frequency ──
    let tierKey;
    if (income === 'premium' || (income === 'high' && frequency === 'daily')) tierKey = 'rec-tier-pro';
    else if (income === 'high' || (city === 'tier1' && frequency === 'daily')) tierKey = 'rec-tier-plus';
    else if (income === 'mid' || frequency === 'daily') tierKey = 'rec-tier-standard';
    else tierKey = 'rec-tier-lite';
    recs.tier = i18n(tierKey);

    // ── Warranty: based on tier, frequency ──
    if (tierKey === 'rec-tier-pro') recs.warranty = i18n('rec-warranty-pro');
    else if (tierKey === 'rec-tier-plus') recs.warranty = i18n('rec-warranty-plus');
    else if (frequency === 'daily') recs.warranty = i18n('rec-warranty-basic-ext');
    else recs.warranty = i18n('rec-warranty-basic');

    return recs;
  }

  function applyRecommendations(recs) {
    const map = {
      size: 'out-size', rope: 'out-rope', voice: 'out-voice',
      speed: 'out-speed', sense: 'out-sense', battery: 'out-battery',
      tier: 'out-tier', warranty: 'out-warranty'
    };

    Object.entries(map).forEach(([key, elId]) => {
      const el = document.getElementById(elId);
      if (el && recs[key] !== undefined) {
        el.textContent = recs[key];
        el.style.color = 'var(--green)';
        setTimeout(() => { el.style.color = ''; }, 300);
      }
    });
  }

  // Event listeners
  ageSlider.addEventListener('input', updateOutput);
  heightSlider.addEventListener('input', updateOutput);
  sceneSelect.addEventListener('change', updateOutput);
  if (visionSelect) visionSelect.addEventListener('change', updateOutput);
  if (citySelect) citySelect.addEventListener('change', updateOutput);
  if (freqSelect) freqSelect.addEventListener('change', updateOutput);
  if (incomeSelect) incomeSelect.addEventListener('change', updateOutput);
  genderRadios.forEach(r => r.addEventListener('change', updateOutput));

  // Initial output
  updateOutput();
}

// ============================================
// 12. Platform: Intelligent Recommendation Demo
// ============================================
// Shared helper: read current configurator state
function readConfiguratorParams() {
  const ageSlider = document.getElementById('config-age');
  const heightSlider = document.getElementById('config-height');
  const sceneSelect = document.getElementById('config-scene');
  const visionSelect = document.getElementById('config-vision');
  const citySelect = document.getElementById('config-city');
  const freqSelect = document.getElementById('config-frequency');
  const incomeSelect = document.getElementById('config-income');

  return {
    age: ageSlider ? parseInt(ageSlider.value) : 45,
    height: heightSlider ? parseInt(heightSlider.value) : 168,
    gender: document.querySelector('input[name="gender"]:checked')?.value || 'male',
    scene: sceneSelect ? sceneSelect.value : 'mixed',
    vision: visionSelect ? visionSelect.value : 'low',
    city: citySelect ? citySelect.value : 'tier2',
    frequency: freqSelect ? freqSelect.value : 'weekly',
    income: incomeSelect ? incomeSelect.value : ''
  };
}

// Scene label map
const sceneLabels = { urban: '城市通勤', indoor: '室内导航', outdoor: '户外公园', mixed: '混合场景' };
const cityLabels = { tier1: '一线城市', tier2: '二线城市', tier3: '三四线', town: '县镇/乡村' };
const visionLabels = { blind: '全盲', low: '低视力', partial: '中度弱视' };
const freqLabels = { daily: '每天', weekly: '每周3-5次', occasional: '偶尔' };
const genderLabels = { male: '男性', female: '女性' };

function initRecommendationDemo() {
  const trigger = document.getElementById('rec-trigger');
  const results = document.getElementById('rec-results');
  if (!trigger || !results) return;

  // Product catalog with scoring attributes
  const catalog = [
    {
      name: '青鸾·城市版 Pro', nameEn: 'QingLuan Urban Pro',
      desc: '旗舰级城市通勤方案，超高灵敏度避障，支持复杂路口导航与公交站识别',
      descEn: 'Flagship urban commute solution with ultra-high sensitivity avoidance, complex intersection navigation & bus stop recognition',
      scene: '城市通勤', sceneEn: 'Urban Commute',
      attrs: { safety: 95, comfort: 85, ease: 90, endurance: 75, value: 70, tier: '旗舰版 Pro', price: '¥9,999' }
    },
    {
      name: '青鸾·室内版 Plus', nameEn: 'QingLuan Indoor Plus',
      desc: '室内精密导航专家，多楼层感知、电梯识别、房间级定位',
      descEn: 'Indoor precision navigation expert with multi-floor perception, elevator recognition & room-level positioning',
      scene: '室内导航', sceneEn: 'Indoor Navigation',
      attrs: { safety: 90, comfort: 92, ease: 95, endurance: 70, value: 80, tier: '进阶版 Plus', price: '¥5,899' }
    },
    {
      name: '青鸾·户外探索版', nameEn: 'QingLuan Outdoor Explorer',
      desc: '大电池长续航，适应公园、步道等户外复杂地形，支持 GPS 轨迹记录',
      descEn: 'Extended battery for long range, adapts to parks, trails & complex outdoor terrain with GPS tracking',
      scene: '户外出行', sceneEn: 'Outdoor',
      attrs: { safety: 85, comfort: 78, ease: 72, endurance: 95, value: 75, tier: '进阶版 Plus', price: '¥7,299' }
    },
    {
      name: '青鸾·全场景版 Pro', nameEn: 'QingLuan All-Scenario Pro',
      desc: '一机通吃所有场景，AI 自动切换导航策略，适合出行需求多变的用户',
      descEn: 'One device for all scenarios — AI auto-switches navigation strategies, ideal for users with varied mobility needs',
      scene: '混合场景', sceneEn: 'Mixed',
      attrs: { safety: 92, comfort: 88, ease: 88, endurance: 85, value: 65, tier: '旗舰版 Pro', price: '¥8,999' }
    },
    {
      name: '青鸾·经济版 Lite', nameEn: 'QingLuan Economy Lite',
      desc: '高性价比入门方案，核心导航功能齐全，适合预算有限的首次用户',
      descEn: 'High-value entry model with full core navigation features, perfect for budget-conscious first-time users',
      scene: '混合场景', sceneEn: 'Mixed',
      attrs: { safety: 78, comfort: 75, ease: 82, endurance: 70, value: 98, tier: '基础版 Lite', price: '¥3,999' }
    },
    {
      name: '青鸾·盲用增强版', nameEn: 'QingLuan Blind Enhanced',
      desc: '专为全盲用户优化，高细节 TTS 播报 + 触觉反馈 + 最大避障灵敏度',
      descEn: 'Optimized for totally blind users — high-detail TTS, tactile feedback & maximum obstacle sensitivity',
      scene: '混合场景', sceneEn: 'Mixed',
      attrs: { safety: 98, comfort: 90, ease: 85, endurance: 78, value: 72, tier: '旗舰版 Pro', price: '¥8,599' }
    }
  ];

  let animating = false;

  trigger.addEventListener('click', () => {
    if (animating) return;
    animating = true;

    // ── Read live configurator params ──
    const p = readConfiguratorParams();
    const sceneCN = i18n('config-scene-' + p.scene) || sceneLabels[p.scene] || p.scene;
    const cityCN = i18n('config-city-' + p.city) || cityLabels[p.city] || p.city;
    const visionCN = i18n('config-vision-' + p.vision) || visionLabels[p.vision] || p.vision;
    const freqCN = i18n('config-freq-' + p.frequency) || freqLabels[p.frequency] || p.frequency;
    const genderCN = i18n('config-' + (p.gender === 'female' ? 'female' : 'male'));
    const incomeInfo = p.income ? i18n('config-income-' + p.income) : i18n('config-income-none');

    // ── Compute dynamic match scores ──
    function computeScore(attrs) {
      // Base weights — balanced across all dimensions
      let wSafety = 0.25, wComfort = 0.25, wEase = 0.20, wEndurance = 0.15, wValue = 0.15;

      // User-parameter weight shifts (keep total ≈ 1.0)
      if (p.vision === 'blind')     { wSafety += 0.10; wEase -= 0.05; wValue -= 0.05; }
      if (p.age > 60)              { wSafety += 0.06; wComfort += 0.06; wEndurance -= 0.06; wValue -= 0.06; }
      if (p.frequency === 'daily')  { wEndurance += 0.08; wValue += 0.02; wComfort -= 0.05; wEase -= 0.05; }
      if (p.scene === 'urban')     { wSafety += 0.05; wComfort -= 0.03; wValue -= 0.02; }
      if (p.scene === 'outdoor')   { wEndurance += 0.10; wEase -= 0.05; wValue -= 0.05; }
      if (p.city === 'tier1')      { wSafety += 0.03; wValue -= 0.03; }
      if (p.income === '' || p.income === 'low')  { wValue += 0.15; wSafety -= 0.10; wComfort -= 0.05; }
      if (p.income === 'premium')  { wComfort += 0.08; wValue -= 0.08; }

      // Scene affinity — significant bonus so matching products stand out
      let sceneBonus = 0;
      if (p.scene === 'urban' && attrs.scene && attrs.scene.includes('城市'))   sceneBonus = 10;
      if (p.scene === 'indoor' && attrs.scene && attrs.scene.includes('室内'))  sceneBonus = 10;
      if (p.scene === 'outdoor' && attrs.scene && attrs.scene.includes('户外')) sceneBonus = 10;
      if (p.scene === 'mixed' && attrs.scene && attrs.scene.includes('混合'))   sceneBonus = 6;

      // Extra affinity for blind-optimized product
      if (p.vision === 'blind' && attrs.safety >= 96) sceneBonus += 5;

      const raw = attrs.safety * wSafety + attrs.comfort * wComfort + attrs.ease * wEase
                + attrs.endurance * wEndurance + attrs.value * wValue + sceneBonus;

      // Cap at 94; floor at 50 to widen spread between products
      return Math.round(Math.min(94, Math.max(50, raw)));
    }

    const scored = catalog.map(p => ({
      ...p,
      score: computeScore(p.attrs)
    })).sort((a, b) => b.score - a.score);

    const top4 = scored.slice(0, 4);
    const avgScore = Math.round(top4.reduce((s, x) => s + x.score, 0) / top4.length);

    // Build sort string for log
    const sortStr = top4.map((x, i) => `P${i + 1}(${x.score}%)`).join(' > ');

    // ── Reset UI ──
    results.style.display = 'block';
    results.style.opacity = '0';
    results.style.transform = 'translateY(10px)';
    results.style.transition = 'opacity 0.4s ease, transform 0.4s ease';

    const progressBar = document.getElementById('rec-progress-bar');
    const progressLabel = document.getElementById('rec-progress-pct');
    const status = document.getElementById('rec-status');
    const thinkingLog = document.getElementById('rec-thinking-log');
    const cards = document.getElementById('rec-cards');

    progressBar.style.width = '0%';
    if (progressLabel) progressLabel.textContent = '0%';
    status.textContent = i18n('rec-demo-init');
    if (thinkingLog) thinkingLog.innerHTML = '';
    cards.innerHTML = '';

    requestAnimationFrame(() => {
      results.style.opacity = '1';
      results.style.transform = 'translateY(0)';
    });

    // i18n helpers with parameter substitution
    const t = (key, params) => { let s = i18n(key); if (params) Object.entries(params).forEach(([k,v]) => { s = s.replace('{'+k+'}', v); }); return s; };
    const ageGroup = p.age > 60 ? t('rec-demo-senior') : p.age > 40 ? t('rec-demo-middle') : t('rec-demo-youth');
    const safetyWeight = p.vision === 'blind' ? t('rec-demo-safety-priority') : p.age > 60 ? t('rec-demo-safety-high') : t('rec-demo-safety-standard');
    const enduranceT = p.frequency === 'daily' ? t('rec-demo-endurance-high') : t('rec-demo-endurance-normal');
    const sceneBonus = p.vision === 'blind' ? '15' : '10';
    const ruleHits = p.vision === 'blind' ? 12 : 8;
    const wSafetyVal = (0.35 + (p.vision === 'blind' ? .10 : 0) + (p.age > 60 ? .08 : 0) + (p.frequency === 'daily' ? .03 : 0) + (p.scene === 'urban' ? .05 : 0)).toFixed(2);
    const valueWeight = (p.income === '' || p.income === 'low') ? t('rec-demo-stage5-value-high') : t('rec-demo-stage5-value-normal');
    const kMeansCl = p.vision === 'blind' ? t('rec-demo-cluster-simple') : t('rec-demo-cluster-normal');
    const clusterType = p.scene === 'outdoor' ? t('rec-demo-cluster-outdoor') : p.scene === 'urban' ? t('rec-demo-cluster-urban') : t('rec-demo-cluster-mixed');
    const strategy = p.vision === 'blind' ? t('rec-demo-strategy-safety') : p.scene === 'outdoor' ? t('rec-demo-strategy-endurance') : t('rec-demo-strategy-balanced');
    const adoptionRate = avgScore > 88 ? '92%' : avgScore > 80 ? '85%' : '78%';

    // ── Thinking stages ──
    const stages = [
      { status: t('rec-demo-stage1-status'), progress: 8, log: t('rec-demo-stage1-log', {catalogCount: catalog.length}), delay: 500 },
      { status: t('rec-demo-stage2-status') + `${genderCN} ${p.age}yr ${p.height}cm...`, progress: 18, log: t('rec-demo-stage2-log', {age: p.age, ageGroup, height: p.height, gender: genderCN, vision: visionCN, city: cityCN}), delay: 550 },
      { status: t('rec-demo-stage3-status', {scene: sceneCN}), progress: 28, log: t('rec-demo-stage3-log', {scene: sceneCN, freq: freqCN, income: incomeInfo, safetyWeight, enduranceThreshold: enduranceT}), delay: 550 },
      { status: t('rec-demo-stage4-status'), progress: 40, log: t('rec-demo-stage4-log', {ruleHits, scene: sceneCN, catalogCount: catalog.length, sceneBonus}), delay: 650 },
      { status: t('rec-demo-stage5-status'), progress: 58, log: t('rec-demo-stage5-log', {wSafety: wSafetyVal, valueWeight}), delay: 700 },
      { status: t('rec-demo-stage6-status'), progress: 72, log: t('rec-demo-stage6-log', {kMeansCluster: kMeansCl, vision: visionCN, clusterType}), delay: 600 },
      { status: t('rec-demo-stage7-status'), progress: 88, log: t('rec-demo-stage7-log', {sortStr, topCount: top4.length, totalCount: catalog.length}), delay: 600 },
      { status: t('rec-demo-stage8-status'), progress: 100, log: t('rec-demo-stage8-log', {strategy, avgScore, adoptionRate, topCount: top4.length}), delay: 500 }
    ];

    let totalDelay = 0;
    stages.forEach((stage, i) => {
      totalDelay += stage.delay;
      setTimeout(() => {
        progressBar.style.width = `${stage.progress}%`;
        if (progressLabel) progressLabel.textContent = `${stage.progress}%`;
        status.textContent = stage.status;
        if (thinkingLog) {
          thinkingLog.innerHTML = stage.log.replace(/\n/g, '<br>');
          thinkingLog.scrollTop = thinkingLog.scrollHeight;
        }

        if (i === stages.length - 1) {
          setTimeout(() => {
            const en = isEn();
            cards.innerHTML = top4.map((p, idx) => `
              <div class="rec-product-card" style="animation-delay:${idx * 0.12}s">
                <h4>${en ? (p.nameEn || p.name) : p.name}</h4>
                <div class="rec-match">${en ? 'Match: ' : '匹配度：'}${p.score}%</div>
                <div class="rec-desc">${en ? (p.descEn || p.desc) : p.desc}</div>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:6px;">
                  <span class="rec-scene-tag">${en ? (p.sceneEn || p.scene) : p.scene}</span>
                  <span style="font-family:var(--font-mono);font-size:0.72rem;color:var(--text-dim);">${p.attrs.tier || ''} · ${p.attrs.price || ''}</span>
                </div>
              </div>
            `).join('');
            const doneTpl = i18n('rec-demo-done');
            const gVal = en ? (p.gender === 'male' ? 'Male' : 'Female') : (p.gender === 'male' ? '男性' : '女性');
            status.textContent = doneTpl.replace('{gender}', gVal).replace('{age}', p.age).replace('{scene}', sceneCN).replace('{count}', top4.length);
            if (thinkingLog) {
              thinkingLog.innerHTML += '<br><br><span style="color: var(--green)">' + i18n('rec-demo-done-suffix') + '</span>';
            }
            animating = false;
          }, 400);
        }
      }, totalDelay - stage.delay);
    });
  });
}

// ============================================
// 13. Platform: Knowledge Graph Node Animation
// ============================================
function initKnowledgeGraphAnimation() {
  const subsystemCards = document.querySelectorAll('.subsystem-card');
  if (subsystemCards.length === 0) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'scale(1)';
        }
      });
    },
    { threshold: 0.15 }
  );

  subsystemCards.forEach((card, i) => {
    card.style.opacity = '0';
    card.style.transform = 'scale(0.9)';
    card.style.transition = `all 0.5s ease ${i * 0.1}s`;
    observer.observe(card);
  });
}

// ============================================
// 14. Platform: Platform Section Parallax
// ============================================
function initPlatformParallax() {
  const platformSection = document.getElementById('platform');
  if (!platformSection) return;

  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      window.requestAnimationFrame(() => {
        const rect = platformSection.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          const yPos = rect.top * 0.03;
          const el = platformSection.querySelector('::before');
          // Apply parallax via CSS custom property on the ::before pseudo-elements inside .platform-layer
          platformSection.querySelectorAll('.platform-layer').forEach(layer => {
            const layerRect = layer.getBoundingClientRect();
            const layerY = (layerRect.top - rect.top) * 0.02;
            layer.style.transform = `translateY(${layerY}px)`;
          });
        }
        ticking = false;
      });
      ticking = true;
    }
  });
}

// ============================================
// 15. Scroll Progress Bar
// ============================================
function initScrollProgress() {
  const bar = document.getElementById('scroll-progress');
  if (!bar) return;
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        const scrollTop = window.scrollY;
        const docHeight = document.documentElement.scrollHeight - window.innerHeight;
        const progress = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
        bar.style.width = `${Math.min(100, progress)}%`;
        ticking = false;
      });
      ticking = true;
    }
  });
}

// ============================================
// 16. Back to Top Button
// ============================================
function initBackToTop() {
  const btn = document.getElementById('back-to-top');
  if (!btn) return;

  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        btn.classList.toggle('visible', window.scrollY > 600);
        ticking = false;
      });
      ticking = true;
    }
  });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

// ============================================
// 17. CTA Floating Bar
// ============================================
function initCTABar() {
  const cta = document.getElementById('cta-bar');
  if (!cta) return;

  let ticking = false;
  let lastVisible = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        const nearBottom = window.scrollY > 400;
        if (nearBottom !== lastVisible) {
          cta.classList.toggle('visible', nearBottom);
          lastVisible = nearBottom;
        }
        ticking = false;
      });
      ticking = true;
    }
  });
}

// ============================================
// 18. Search
// ============================================
function initSearch() {
  const toggle = document.getElementById('search-toggle');
  const overlay = document.getElementById('search-overlay');
  const close = document.getElementById('search-close');
  const input = document.getElementById('search-input');
  const results = document.getElementById('search-results');

  if (!toggle || !overlay) return;

  // Build search index from page content
  let searchIndex = [];
  function buildIndex() {
    searchIndex = [];
    document.querySelectorAll('section[id]').forEach(section => {
      const id = section.id;
      const title = section.querySelector('.section-title')?.textContent.trim() || '';
      const tag = section.querySelector('.section-tag')?.textContent.trim() || '';
      const text = section.textContent.trim().substring(0, 800);

      if (id === 'hero') {
        searchIndex.push({ id, title: '青鸾云步 · 首页', tag: '/ Hero', text: '智能导盲机器人 为视障人士打造安全可靠的智能出行伴侣' });
      } else if (title) {
        searchIndex.push({ id, title, tag, text });
      }
    });
    // Add FAQ items
    document.querySelectorAll('.faq-question').forEach(q => {
      const text = q.textContent.trim();
      searchIndex.push({ id: 'faq', title: text, tag: '/ FAQ', text });
    });
  }

  function openSearch() {
    buildIndex();
    overlay.classList.add('open');
    input.value = '';
    results.innerHTML = '<p class="search-hint">输入关键词搜索页面内容…</p>';
    setTimeout(() => input.focus(), 100);
  }

  function closeSearch() {
    overlay.classList.remove('open');
  }

  function doSearch(query) {
    const q = query.toLowerCase().trim();
    if (!q) {
      results.innerHTML = '<p class="search-hint">输入关键词搜索页面内容…</p>';
      return;
    }

    const hits = searchIndex.filter(item =>
      item.title.toLowerCase().includes(q) ||
      item.text.toLowerCase().includes(q)
    );

    if (hits.length === 0) {
      results.innerHTML = '<p class="search-no-results">未找到相关内容，试试其他关键词</p>';
      return;
    }

    // Deduplicate by section id
    const seen = new Set();
    const unique = hits.filter(h => {
      const key = h.id + h.title;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).slice(0, 8);

    results.innerHTML = unique.map(h => `
      <div class="search-result-item" data-target="#${h.id}" tabindex="0">
        <div>${highlightMatch(h.title, q)}</div>
        <div class="search-section-tag">${escapeHtml(h.tag)}</div>
      </div>
    `).join('');

    // Click handlers
    results.querySelectorAll('.search-result-item').forEach(item => {
      item.addEventListener('click', () => navigateToResult(item));
      item.addEventListener('keydown', (e) => { if (e.key === 'Enter') navigateToResult(item); });
    });
  }

  function highlightMatch(text, query) {
    const idx = text.toLowerCase().indexOf(query);
    if (idx === -1) return escapeHtml(text);
    return escapeHtml(text.substring(0, idx)) +
      '<strong>' + escapeHtml(text.substring(idx, idx + query.length)) + '</strong>' +
      escapeHtml(text.substring(idx + query.length));
  }

  function navigateToResult(item) {
    const targetId = item.dataset.target.substring(1);
    closeSearch();
    const target = document.getElementById(targetId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  toggle.addEventListener('click', openSearch);
  close.addEventListener('click', closeSearch);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeSearch();
  });
  input.addEventListener('input', () => doSearch(input.value));
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && overlay.classList.contains('open')) closeSearch();
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      openSearch();
    }
  });
}

// ============================================
// 19. FAQ Accordion
// ============================================
function initFAQ() {
  document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.parentElement;
      const isOpen = item.classList.contains('open');
      // Close all
      document.querySelectorAll('.faq-item.open').forEach(el => el.classList.remove('open'));
      // Toggle clicked
      if (!isOpen) item.classList.add('open');
      btn.setAttribute('aria-expanded', !isOpen);
    });
  });
}

// ============================================
// 20. Accessibility Mode
// ============================================
function initAccessibilityMode() {
  const toggle = document.getElementById('a11y-toggle');
  if (!toggle) return;

  const saved = localStorage.getItem('qingluan-a11y') === 'true';
  if (saved) {
    document.documentElement.setAttribute('data-a11y', 'true');
    toggle.classList.add('active');
  }

  toggle.addEventListener('click', () => {
    const isActive = document.documentElement.getAttribute('data-a11y') === 'true';
    if (isActive) {
      document.documentElement.removeAttribute('data-a11y');
      toggle.classList.remove('active');
      localStorage.setItem('qingluan-a11y', 'false');
    } else {
      document.documentElement.setAttribute('data-a11y', 'true');
      toggle.classList.add('active');
      localStorage.setItem('qingluan-a11y', 'true');
    }
  });
}

// ============================================
// 21. Auto Theme (System Preference)
// ============================================
function initAutoTheme() {
  const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

  function handleSystemThemeChange() {
    const current = localStorage.getItem('qingluan-theme');
    // Only auto-switch if user hasn't manually chosen a theme yet
    if (!current || current === 'dark') {
      // If user has never set a theme, follow system preference
      const systemPrefersDark = mediaQuery.matches;
      const existingChoice = localStorage.getItem('qingluan-theme-set');
      if (!existingChoice) {
        // First visit: set initial based on system
        const theme = systemPrefersDark ? 'dark' : 'light';
        ThemeManager.set(theme);
        updateActiveOption(theme);
      }
    }
  }

  function updateActiveOption(theme) {
    document.querySelectorAll('.theme-option').forEach(o => {
      o.classList.toggle('active', o.dataset.theme === theme);
    });
  }

  // Mark that user made a manual choice
  document.querySelectorAll('.theme-option').forEach(opt => {
    opt.addEventListener('click', () => {
      localStorage.setItem('qingluan-theme-set', 'true');
    });
  });

  // Initial auto-detect (only if no saved preference)
  if (!localStorage.getItem('qingluan-theme-set')) {
    handleSystemThemeChange();
  }

  mediaQuery.addEventListener('change', handleSystemThemeChange);
}

// ============================================
// 22. Language Switch (ZH / EN)
// ============================================
const I18N = {
  zh: {
    'nav-home':'首页','nav-bg':'背景','nav-about':'关于','nav-products':'产品','nav-tech':'技术','nav-platform':'智能平台','nav-faq':'FAQ','nav-contact':'联系',
    'hero-badge':'青鸾云步 · AI GUIDE ROBOT','hero-subtitle':'智能导盲机器人 · 为视障人士打造的智能出行伴侣','hero-btn1':'探索产品 →','hero-btn2':'核心技术',
    'hero-scroll':'SCROLL','search-placeholder':'搜索页面内容...','search-hint':'输入关键词搜索页面内容…','search-no':'未找到相关内容，试试其他关键词',
    'cta-text':'准备好体验智能导盲了吗？','cta-btn':'预约体验 →','theme-label':'背景主题','back-top':'回到顶部','lang-title':'Switch to English','a11y-title':'无障碍模式','search-title':'搜索',
    'footer-text':'Made with ♥ · 青鸾云步 © 2026',
    'sec-home-tag':'/ Overview','sec-home-title':'青鸾云步','sec-home-desc':'智能导盲机器人，为视障人士打造安全可靠的出行伴侣',
    'sec-bg-tag':'/ Background','sec-bg-title':'背景故事','sec-bg-desc':'时代的痛点，技术的答案',
    'sec-about-tag':'/ About','sec-about-title':'关于我们','sec-about-desc':'以技术之心，为视障人士点亮前行的路',
    'sec-products-tag':'/ Products','sec-products-title':'产品规格','sec-products-desc':'双芯片架构 · 多传感器融合 · 全场景智能导航',
    'sec-tech-tag':'/ Technology','sec-tech-title':'核心技术','sec-tech-desc':'从感知到控制的完整技术栈',
    'sec-platform-tag':'/ Platform','sec-platform-title':'智能平台','sec-platform-desc':'三层架构 · 四子系统协同 · 智能推荐引擎',
    'sec-faq-tag':'/ FAQ','sec-faq-title':'常见问题','sec-faq-desc':'关于青鸾云步，你可能想了解的一切',
    'sec-contact-tag':'/ Contact','sec-contact-title':'联系我们','sec-contact-desc':'电话 198-8859-5523 · 邮箱 19888595523@163.com',
    'bg-stat-global':'全球视障人士','bg-stat-src':'WHO 2024 数据','bg-stat-dog':'导盲犬配比（中国）','bg-stat-period':'导盲犬培育周期','bg-stat-cost':'单只导盲犬成本',
    'bg-pain-title':'行业的三大痛点',
    'bg-pain1-title':'供需严重失衡','bg-pain1-desc':'中国约 1,730 万视障人士，而全国合格的导盲犬不足 <strong>200 只</strong>。平均每 4 万人才有 1 只，盲人排队等待导盲犬的时间长达 3-5 年。','bg-pain1-quote':'"导盲犬比大熊猫还稀有"<br>— 中国盲人协会',
    'bg-pain2-title':'成本门槛极高','bg-pain2-desc':'一只合格导盲犬的培育成本约 <strong>15-20 万元</strong>，包含 18-24 个月训练、专业饲养和配对调试。即使申请到，后续每年饲养费用也超过 <strong>8,000 元</strong>。','bg-pain2-quote':'产业无法规模化，成本无法摊薄',
    'bg-pain3-title':'传统电子设备不足','bg-pain3-desc':'现有电子导盲设备普遍存在 <strong>导航精度不足、交互不自然、缺乏主动避障</strong> 三大缺陷。单一传感器的可靠性在复杂城市环境中无法满足安全需求。','bg-pain3-quote':'能用，但不够好用<br>— 盲人用户真实反馈',
    'bg-compare-title':'为什么选择青鸾云步？','bg-compare-dim':'维度','bg-compare-dog':'导盲犬','bg-compare-stick':'电子导盲杖','bg-compare-us':'青鸾云步',
    'bg-compare-cost-label':'成本','bg-compare-dog-cost':'¥15-20 万','bg-compare-stick-cost':'¥500-5,000','bg-compare-us-cost':'¥3,999 起',
    'bg-compare-supply-label':'供应量','bg-compare-dog-supply':'< 200 只/年','bg-compare-stick-supply':'量产不限','bg-compare-us-supply':'可量产',
    'bg-compare-avoid-label':'主动避障','bg-compare-dog-avoid':'✓ 天生本能','bg-compare-stick-avoid':'✗ 仅距离提示','bg-compare-us-avoid':'✓ 视觉+超声双通道',
    'bg-compare-path-label':'路径规划','bg-compare-dog-path':'✗ 需记忆训练','bg-compare-stick-path':'✗ 无','bg-compare-us-path':'✓ A* + 势场法',
    'bg-compare-voice-label':'语音交互','bg-compare-dog-voice':'✗ 无','bg-compare-stick-voice':'✗ 简单蜂鸣','bg-compare-us-voice':'✓ 离线 AI + TTS',
    'bg-compare-maint-label':'维护成本','bg-compare-dog-maint':'¥8,000+/年','bg-compare-stick-maint':'低','bg-compare-us-maint':'低（充电即可）',
    'bg-mission-p1':'我们相信，<strong>科技的意义不在于炫技，而在于解决真实的问题</strong>。青鸾云步的诞生，源于一个简单的想法——让每一位视障人士都能拥有一只\'电子导盲犬\'，不再因成本、稀缺和等待而困于方寸之间。',
    'bg-mission-p2':'从双足行走的第一行代码，到如今的双芯片架构与 AI 视觉融合，我们花了无数个日夜，只为让技术真正落地——<strong>不是实验室里的玩具，而是街角巷尾的伙伴</strong>。',
    'bg-mission-vision':'愿景','bg-mission-vision-desc':'打造人人都用得起的智能导盲机器人',
    'bg-mission-way':'方式','bg-mission-way-desc':'双芯片架构 · 多传感器融合 · 开源协作',
    'bg-mission-heart':'初心','bg-mission-heart-desc':'让科技温暖生活，从一公里开始',
    'platform-layer-app':'应用层','platform-layer-app-sub':'Application Layer','platform-layer-app-1-title':'销售平台前端','platform-layer-app-1-desc':'智能导盲产品展示与交易平台',
    'platform-layer-app-2-title':'高价值需求推送','platform-layer-app-2-desc':'精准匹配用户画像的个性化推荐',
    'platform-connector-1':'数据流转 · 智能匹配',
    'platform-layer-match':'匹配层','platform-layer-match-sub':'Matching Layer','platform-layer-match-1-title':'信息图谱关联分析','platform-layer-match-1-desc':'动态关联知识图谱构建与推理',
    'platform-layer-match-2-title':'需求匹配引擎','platform-layer-match-2-desc':'多层模糊评价 + 聚类推荐算法',
    'platform-connector-2':'实时采集 · 自动监测',
    'platform-layer-collect':'采集层','platform-layer-collect-sub':'Collection Layer','platform-layer-collect-1-title':'爬虫节点管理','platform-layer-collect-1-desc':'分布式信息自动监测与发现',
    'platform-layer-collect-2-title':'需求情报采集','platform-layer-collect-2-desc':'多源异构数据汇聚与清洗',
    'platform-subsys-title':'四大子系统',
    'platform-subsys-1-title':'需求情报采集','platform-subsys-1-desc':'自动化爬虫节点管理，多源需求数据实时监测与发现，构建全面的需求情报网络','platform-subsys-1-t1':'分布式爬虫','platform-subsys-1-t2':'实时监测','platform-subsys-1-t3':'数据汇聚',
    'platform-subsys-2-title':'需求清洗分类','platform-subsys-2-desc':'基于 NLP 与规则的异构数据清洗，智能分类标注，提取高价值需求特征','platform-subsys-2-t1':'NLP处理','platform-subsys-2-t2':'智能分类','platform-subsys-2-t3':'特征提取',
    'platform-subsys-3-title':'价值评估匹配','platform-subsys-3-desc':'多层模糊评价模型，综合用户画像与场景特征，实现需求-产品精准映射','platform-subsys-3-t1':'模糊评价','platform-subsys-3-t2':'用户画像','platform-subsys-3-t3':'精准匹配',
    'platform-subsys-4-title':'知识图谱构建','platform-subsys-4-desc':'基于 Deep KE 框架的导盲领域知识图谱，支持动态关联推理与语义搜索','platform-subsys-4-t1':'Deep KE','platform-subsys-4-t2':'关联推理','platform-subsys-4-t3':'语义搜索',
    'platform-config-title':'智能参数化设置','platform-config-desc':'根据用户特征自动推荐最优产品配置方案',
    'config-gender':'性别','config-male':'男性','config-female':'女性',
    'config-age':'年龄','config-height':'身高 (cm)','config-scene':'使用场景','config-scene-urban':'城市通勤','config-scene-indoor':'室内导航','config-scene-outdoor':'户外公园','config-scene-mixed':'混合场景',
    'config-vision':'视力状况','config-vision-blind':'全盲 (无光感)','config-vision-low':'低视力 (光感/手动)','config-vision-partial':'中度弱视 (指数/0.05)',
    'config-city':'所在城市','config-city-tier1':'一线城市 (北上广深)','config-city-tier2':'二线城市','config-city-tier3':'三四线城市','config-city-town':'县镇 / 乡村',
    'config-frequency':'出行频率','config-freq-daily':'每天出行','config-freq-weekly':'每周 3-5 次','config-freq-occasional':'偶尔出行 (每周 < 3 次)',
    'config-income':'月收入范围','config-income-opt':'选填','config-income-none':'不透露','config-income-low':'3,000 元以下','config-income-mid':'3,000 – 6,000 元','config-income-high':'6,000 – 10,000 元','config-income-premium':'10,000 元以上',
    'config-output-header':'推荐配置方案','config-out-size':'机身尺寸','config-out-rope':'牵引绳长','config-out-voice':'语音模式','config-out-speed':'行驶速度','config-out-sense':'避障灵敏度','config-out-battery':'电池容量','config-out-tier':'推荐档位','config-out-warranty':'保修建议',
    'platform-recommend-title':'个性化推荐系统',
    'platform-rec-step1-title':'需求预测','platform-rec-step1-desc':'基于用户画像与历史行为，预测潜在导盲需求',
    'platform-rec-step2-title':'产品匹配','platform-rec-step2-desc':'知识图谱语义匹配 + 多层模糊评价筛选最优产品',
    'platform-rec-step3-title':'智能推荐','platform-rec-step3-desc':'个性化排序 + 场景适配，一键推送最优方案',
    'platform-rec-btn':'🔍 智能推荐',
    'platform-tech-title':'平台核心技术',
    'platform-tech-1-title':'分布式爬虫引擎','platform-tech-1-desc':'多节点协同采集，智能反爬策略，支持动态页面渲染与定时任务调度',
    'platform-tech-2-title':'Deep KE 知识图谱','platform-tech-2-desc':'导盲领域专用知识图谱框架，支持实体抽取、关系推理与动态更新',
    'platform-tech-3-title':'聚类推荐算法','platform-tech-3-desc':'K-Means + 层次聚类，结合协同过滤与内容推荐，多维度需求匹配',
    'platform-tech-4-title':'多层模糊评价','platform-tech-4-desc':'构建多层次评价指标体系，模糊综合评价法量化需求-产品适配度',
    'platform-stat-1':'开发效率提升','platform-stat-1-desc':'技术复用节省开发时间',
    'platform-stat-2':'自动化采集','platform-stat-2-desc':'零人工干预信息监测',
    'platform-stat-3':'数据变现','platform-stat-3-desc':'需求数据可二次商业变现',
    'platform-stat-4':'匹配精度','platform-stat-4-desc':'多层模糊评价推荐精度',
    // Configurator output values
    'rec-size-small':'小型','rec-size-medium':'中型','rec-size-large':'大型',
    'rec-voice-standard-male':'标准男声','rec-voice-standard-female':'标准女声','rec-voice-gentle-male':'温和男声','rec-voice-gentle-female':'温和女声','rec-voice-hd-male':'高细节男声','rec-voice-hd-female':'高细节女声',
    'rec-sense-standard':'标准','rec-sense-medium':'中','rec-sense-high':'高','rec-sense-ultra':'超高',
    'rec-tier-pro':'旗舰版 Pro','rec-tier-plus':'进阶版 Plus','rec-tier-standard':'标准版','rec-tier-lite':'基础版 Lite',
    'rec-warranty-pro':'3年尊享保','rec-warranty-plus':'2年安心保','rec-warranty-basic-ext':'1年基础保+延保可选','rec-warranty-basic':'1年基础保',
    // Recommendation demo
    'rec-demo-init':'引擎初始化...','rec-demo-stage1-status':'⚙️ 引擎初始化完成，建立推理上下文...','rec-demo-stage1-log':'加载 Deep KE 知识图谱引擎 v3.2\n注册实体：用户画像, 产品型号, 场景特征, 传感器参数\n初始化模糊评价矩阵 (5层 × 12指标)',
    'rec-demo-stage2-status':'👤 读取用户画像：','rec-demo-stage2-log':'年龄: {age}岁 ({ageGroup})\n身高: {height}cm\n性别: {gender}\n视力: {vision}\n所在城市: {city}','rec-demo-youth':'青年族群','rec-demo-middle':'中年族群','rec-demo-senior':'银发族群',
    'rec-demo-stage3-status':'📊 构建需求特征空间 — 场景: {scene}...','rec-demo-stage3-log':'使用场景: {scene}\n出行频率: {freq}\n收入: {income}\n→ 安全权重: {safetyWeight}\n→ {enduranceThreshold}','rec-demo-safety-high':'HIGH(+8%)','rec-demo-safety-priority':'PRIORITY(+10%)','rec-demo-safety-standard':'标准','rec-demo-endurance-high':'续航阈值 ≥ 2.0h','rec-demo-endurance-normal':'续航阈值 ≥ 1.2h',
    'rec-demo-stage4-status':'🕸️ 知识图谱关联推理中...','rec-demo-stage4-log':'实体链接: 用户画像 → 关联规则库 (命中 {ruleHits} 条)\n关系推理: {scene} ↔ 产品 相容性矩阵\n路径发现: 2-hop 推理 → 候选集 {catalogCount} 条\n场景匹配度加权: {scene} 场景优先 +{sceneBonus}%',
    'rec-demo-stage5-status':'🧠 多层模糊评价计算...','rec-demo-stage5-log':'第1层: 安全性 → w={wSafety}\n第2层: 舒适性 → 自适应权重\n第3层: 易用性 → 自适应权重\n第4层: 续航   → 自适应权重\n第5层: 性价比 → {valueWeight}',
    'rec-demo-stage5-value-normal':'标准','rec-demo-stage5-value-high':'权重上调(预算敏感)',
    'rec-demo-stage6-status':'📈 聚类分析 + 协同过滤...','rec-demo-stage6-log':'K-Means: {kMeansCluster}\n簇分配: {vision}用户→{clusterType}\n协同过滤: 相似用户 Top-K=3\nPearson 相关系数 > 0.83','rec-demo-cluster-simple':'k=3 精简聚类','rec-demo-cluster-normal':'k=4 聚类','rec-demo-cluster-outdoor':'户外型簇','rec-demo-cluster-urban':'城市型簇','rec-demo-cluster-mixed':'混合型簇',
    'rec-demo-stage7-status':'🎯 综合排序 + 场景适配...','rec-demo-stage7-log':'归一化: Min-Max Scaling\n加权融合: Σ(λi × score_i)\n排序: {sortStr}\n场景校验: {topCount}/{totalCount} 通过相容性检查',
    'rec-demo-stage8-status':'✨ 生成个性化推荐方案','rec-demo-stage8-log':'推荐策略: {strategy}\n置信度: 平均 {avgScore}%\n采纳率预估: {adoptionRate}\n✓ 方案就绪 → 输出 Top-{topCount}','rec-demo-strategy-safety':'安全优先策略','rec-demo-strategy-endurance':'续航优先策略','rec-demo-strategy-balanced':'均衡覆盖策略',
    'rec-demo-done':'✅ 推荐完成 — 基于 {gender} {age}岁 {scene} 场景，匹配 {count} 款产品','rec-demo-done-suffix':'✓ 推理完成，耗时 ~4.6s',
    'rec-demo-progress-label':'推理进程',
    'faq-q1':'青鸾云步和导盲犬有什么区别？','faq-a1':'导盲犬需要 18-24 个月培育，成本 15-20 万元，全国不足 200 只，等待时间长达 3-5 年。青鸾云步可量产、即买即用，价格 ¥3,999 起，且具备导盲犬所没有的 <strong>A* 路径规划、AI 视觉避障和语音导航</strong>功能。',
    'faq-q2':'续航多久？充电方便吗？','faq-a2':'标准版搭载 5000mAh 锂电池，全功能续航约 <strong>1.5 小时 / 5-8 公里</strong>；旗舰版可升级至 8000mAh，续航达 <strong>2.5 小时 / 12 公里</strong>。支持 Type-C 快充，2 小时充满，普通充电宝即可应急充电。',
    'faq-q3':'安全性如何保证？','faq-a3':'三重独立安全机制：<strong>① 通信看门狗</strong>（1000ms 超时自动停机）、<strong>② IMU 摔倒检测</strong>（倾角 > 45° 紧急断电）、<strong>③ 力传感器急停</strong>（推力 > 20N 反向制动）。任意一路触发即进入安全状态，冗余设计确保万无一失。',
    'faq-q4':'售后和保修政策是怎样的？','faq-a4':'基础版享 <strong>1 年基础保修</strong>，进阶版 Plus 享 <strong>2 年安心保修</strong>，旗舰版 Pro 享 <strong>3 年尊享保修</strong>。所有产品支持全国顺丰包邮、7 天无理由退换，客服热线 198-8859-5523 工作日 9:00-18:00 在线。',
    'faq-q5':'可以在室外雨天使用吗？','faq-a5':'机身具备 <strong>IP54 防水防尘</strong>等级，可应对小雨和溅水，但不建议在大雨或积水环境中使用。超声波传感器在雨天仍可正常工作，视觉摄像头在雨雾天气会自动调低置信度阈值并更依赖超声测距。',
    'faq-q6':'如何适配不同身高的用户？','faq-a6':'牵引绳长可调（110cm / 120cm / 135cm），腿高自适应调节（70-130mm），根据用户在智能参数面板中填写的性别、年龄、身高自动推荐最优配置。5 连杆并联机构全程自平衡，无需手动校准。',
    'md-home': "**青鸾云步智能导盲机器人**，为视障人士打造安全、可靠、智能的出行伴侣。\n\n---\n\n### 核心价值\n\n- **安全可靠** — 多传感器融合 + 冗余安全架构，毫秒级紧急响应\n- **智能导航** — A*全局路径规划 + 人工势场局部避障，自主穿越复杂环境\n- **自然交互** — 多维力传感器随行 + 离线AI语音指令，人机协作天衣无缝\n- **全时守护** — 摔倒检测、看门狗保护、紧急制动，三重安全防线\n\n### 技术亮点\n\n| 系统 | 技术 | 指标 |\n|------|------|------|\n| 感知 | FOMO 目标检测 | 10Hz 帧率，30ms 推理 |\n| 规划 | A* + 势场法 | 100×100 栅格，8方向路径 |\n| 控制 | 串级 PID + 5连杆逆运动学 | 50-200Hz 控制频率 |\n| 交互 | 导纳控制 + 离线 ASR | 20命令词，>92% 识别率 |\n| 安全 | 通信看门狗 + IMU 摔倒检测 | 1000ms 超时停机 |\n\n> 技术不是冰冷的代码，而是温暖人心的力量。",
    'md-about': "### 公司使命\n\n我们致力于通过先进的机器人技术与人工智能，为视障人士创造独立、自信的出行体验。每一行代码，每一个算法，都指向同一个愿景——**让科技温暖生活**。\n\n### 项目背景\n\n本产品诞生于对真实社会需求的深度洞察。全球有超过 2.85 亿视障人士，传统的导盲犬训练周期长（18-24 个月）、成本高（约 15-20 万元）、供应量极为有限。而电子导盲设备在复杂环境下的导航能力、人机交互的自然度始终未能达到实用门槛。\n\n我们以 **ESP32-S3 + OpenMV H7 Plus 双芯片** 为核心架构，融合计算机视觉、路径规划、运动控制和语音交互，打造了一款真正可用的智能导盲机器人。\n\n### 研发团队\n\n- **硬件架构** — ESP32-S3 运动控制 + OpenMV H7 Plus 视觉规划\n- **感知算法** — FOMO 目标检测 + 畸变校正 + 超声测距融合\n- **运动控制** — 串级 PID + 5连杆逆运动学 + BLDC FOC\n- **人机交互** — 导纳控制力控随行 + 离线 AI 语音 + TTS\n- **系统集成** — 多传感器融合 + 通信协议 + 安全架构\n\n### 发展历程\n\n| 阶段 | 时间 | 里程碑 |\n|------|------|--------|\n| V1 | 初期 | 双足行走 + 基础 PID 控制 |\n| V2 | 中期 | 引入超声波避障 + 航向恢复 |\n| V3 | 当前 | A* 全局规划 + FOMO 视觉 + 双芯片架构 |\n\n### 开源精神\n\n项目代码已完全开源，欢迎开发者贡献与改进。我们相信开放协作能加速技术进步，让更多人受益于智能辅助技术。",
    'md-products': "### 硬件平台\n\n| 组件 | 型号 | 说明 |\n|------|------|------|\n| 运动控制 MCU | ESP32-S3 DevKitC-1 | 240MHz 双核 Xtensa LX7 |\n| 视觉/规划 MCU | OpenMV H7 Plus | Cortex-M7 @ 480MHz, 32MB SDRAM |\n| 姿态传感器 | MPU6050 | I2C 接口，400kHz |\n| 超声波测距 | 高精度超声波模块 | 温度补偿，±0.5cm 精度 |\n| 视觉传感器 | OV5640 | QVGA, FOMO 目标检测 |\n| 探测云台 | Pan 舵机 | 超声波 + OpenMV 共架 |\n| 腿部执行器 | MG996R 舵机 × 4 | PCA9685 PWM 驱动 |\n| 行走执行器 | BLDC 轮毂电机 × 2 | FOC 矢量控制 |\n| 人机交互 | 多维力传感器 + 离线 ASR | 导纳控制 + 语音 |\n| 供电 | 3S 5000mAh LiPo | 全功能续航约 1.5h |\n\n### 系统架构\n\n```\n┌────────────────────────────────────────────┐\n│ OpenMV H7 Plus (10Hz 感知规划)              │\n│ 视觉推理 → A*规划 → 超声测距 → 势场避障     │\n└────────────────┬───────────────────────────┘\n                 │ UART @ 921600 bps\n┌────────────────┴───────────────────────────┐\n│ ESP32-S3 (50-200Hz 运动控制)                 │\n│ PID控制 → 逆运动学 → 舵机/电机 → ASR/TTS    │\n└────────────────────────────────────────────┘\n```\n\n### 技术指标\n\n| 指标 | 数值 |\n|------|------|\n| 系统帧率 | 10Hz（感知+规划+控制闭环） |\n| 控制频率 | 50-200Hz（PID + 电机） |\n| 障碍物定位精度 | 横向 ±7cm，前向 ±2cm @1m |\n| 超声波测距精度 | ±0.5cm（温度补偿后） |\n| 最大行驶速度 | 0.5m/s |\n| 腿高范围 | 70-130mm（自适应调节） |\n| 转向方式 | 零半径原地转向 |\n| 硬件成本 | 可控量产成本，远低于导盲犬 |\n\n### 核心能力\n\n**感知层** — FOMO 目标检测模型，30ms 级推理，融合超声波精确测距，双通道冗余避障决策\n\n**规划层** — A* 全局路径规划（100×100 栅格，8方向），人工势场局部避障\n\n**控制层** — 串级 PID（速度环+直立环+转向环），5连杆逆运动学，FOC 轮毂电机驱动\n\n**交互层** — 导纳控制力控随行，离线 AI 语音识别（20 个命令词，>92% 识别率），TTS 语音播报，WiFi WebSocket 远程监控",
    'md-technology': "### 双芯片分工架构\n\nOpenMV H7 Plus 负责上游感知与路径规划，ESP32-S3 负责下游运动控制与人机交互。两芯片通过 UART @ 921600 bps 高速通信，关键数据流在单芯片内部闭环。\n\n**设计优势：** 感知与控制解耦，视觉推理大内存需求由 OpenMV 32MB SDRAM 满足，实时控制由 ESP32-S3 专用处理器保证，各司其职。\n\n### 视觉感知 — FOMO 目标检测\n\n采用 TensorFlow Lite Micro 部署 FOMO（Faster Objects, More Objects）模型：\n\n| 项目 | 参数 |\n|------|------|\n| 输入 | QVGA 240×240，RGB565 |\n| 检测类别 | 椅子、柱子、手 + 背景 |\n| 置信度阈值 | ≥ 0.5 |\n| 推理耗时 | ~30ms/帧 |\n| 输出特征图 | 30×30（8× 下采样） |\n\n配合 OV5640 畸变校正（校正后残余 < 0.1°），视觉定位精度满足实地导航需求。\n\n### A* 全局路径规划\n\n100×100 栅格地图覆盖 10×10 米区域，8方向邻域搜索 + 欧几里得距离启发式，单次规划耗时 20-50ms：\n\n```\nf(n) = g(n) + h(n)\ng(n): 起点到当前节点的实际代价\nh(n): 当前节点到终点的欧几里得距离估计\n```\n\n路径跟踪取前方第 3-5 格作为局部目标，方向作为势场法引力输入。\n\n### 人工势场局部避障\n\n```\nU_total(q) = U_att(q) + U_rep(q)\nF(q) = -∇U(q)\n```\n\n引力指向 A* 局部目标，斥力来自障碍物方向，合力决定左右轮避障因子。双轮足零半径转向能力使势场输出可按\"先转后走\"执行，与传统车式\"边转边走\"相比，与势场梯度方向更吻合。\n\n### 串级 PID 控制架构\n\n四环串级控制：速度环（P）→ 直立环（PD）→ 转向环（P）→ 高度环（P）\n\n**关键设计：** 直立环使用 PD 而非 PID — 倒立摆控制中积分项引入相位滞后，降低稳定性。PD 的比例项提供恢复力，微分项提供阻尼。\n\nPID 参数随腿高自适应调节（70-130mm），通过二次函数平滑插值计算最优参数。\n\n### 5连杆并联机构逆运动学\n\n采用 5 连杆闭链并联机构，较传统串联腿具备更高刚度和承载能力：\n\n| 对比项 | 串联腿 | 5连杆并联 |\n|--------|--------|-----------|\n| 刚度 | 低（悬臂受力） | 高（三角封闭受力） |\n| 承载比 | 低 | 高（适合重载导盲） |\n| 舵机负载 | 大 | 小（力由连杆分担） |\n\n### 安全架构\n\n```\n条件1: >300ms 未收到 OpenMV 帧 → 保持减速至零\n条件2: >1000ms 未收到 OpenMV 帧 → 电机归零，舵机锁位\n条件3: 俯仰角 > 45°（摔倒）→ 紧急切断电源\n条件4: 推力 > 20N（急停意图）→ 反向制动 200ms\n```\n\n三重独立安全机制：通信看门狗 + IMU 摔倒检测 + 力传感器急停，任意一路触发即进入安全状态。\n\n### 交互技术\n\n- **导纳控制：** F_push / D_viscous → 目标速度，0.5N-20N 线性映射\n- **离线 ASR：** ESP-SR 框架，20 个导盲场景命令词，安静环境 >92% 识别率\n- **TTS 播报：** 障碍物提示、电量不足、命令确认，预合成音频资源\n- **WebSocket 监控：** 1Hz JSON 状态广播，手机浏览器实时仪表盘",
    'md-contact': "我们期待与您交流合作，共同推动智能辅助技术的发展。\n\n---\n\n### 联系方式\n\n- **邮箱：** 19888595523@163.com\n- **电话：** 198-8859-5523\n- **GitHub：** [github.com/青鸾云步](https://github.com)\n- **项目开源：** 全部源代码开放，欢迎贡献与反馈\n\n### 合作方向\n\n- **技术合作：** 传感器融合、路径规划、运动控制算法研究\n- **产品应用：** 导盲机器人试点部署、场景适配开发\n- **学术交流：** 论文引用、实验数据共享、联合课题申报\n- **社区贡献：** 代码提交、文档完善、测试验证\n\n### 加入我们\n\n如果你对机器人技术、计算机视觉或人机交互充满热情，欢迎加入我们的开源社区。\n\n**我们正在寻找：**\n\n- 嵌入式系统工程师（ESP32/STM32）\n- 计算机视觉算法工程师\n- 运动控制与机器人学研究员\n- 产品设计与用户体验专家\n\n---\n\n> 青鸾展翼，云步天下 — 我们一直在路上。"
  },
  en: {
    'nav-home':'Home','nav-bg':'Background','nav-about':'About','nav-products':'Products','nav-tech':'Technology','nav-platform':'Platform','nav-faq':'FAQ','nav-contact':'Contact',
    'hero-badge':'QingLuan Cloud Walk · AI GUIDE ROBOT','hero-subtitle':'Smart Guide Robot · An AI-powered mobility companion for the visually impaired','hero-btn1':'Explore Products →','hero-btn2':'Core Technology',
    'hero-scroll':'SCROLL','search-placeholder':'Search page content...','search-hint':'Type a keyword to search…','search-no':'No results found. Try another keyword.',
    'cta-text':'Ready to experience smart navigation?','cta-btn':'Book a Demo →','theme-label':'Theme','back-top':'Back to Top','lang-title':'切换到中文','a11y-title':'Accessibility Mode','search-title':'Search',
    'footer-text':'Made with ♥ · QingLuan Cloud Walk © 2026',
    'sec-home-tag':'/ Overview','sec-home-title':'QingLuan Cloud Walk','sec-home-desc':'Smart guide robot — a safe and intelligent mobility companion for the visually impaired',
    'sec-bg-tag':'/ Background','sec-bg-title':'Background Story','sec-bg-desc':'The pain points of our time, answered by technology',
    'sec-about-tag':'/ About','sec-about-title':'About Us','sec-about-desc':'Lighting the way forward for the visually impaired with technology',
    'sec-products-tag':'/ Products','sec-products-title':'Product Specs','sec-products-desc':'Dual-chip architecture · Multi-sensor fusion · All-scenario intelligent navigation',
    'sec-tech-tag':'/ Technology','sec-tech-title':'Core Technology','sec-tech-desc':'A complete technology stack from perception to control',
    'sec-platform-tag':'/ Platform','sec-platform-title':'Intelligent Platform','sec-platform-desc':'Three-layer architecture · Four subsystems · Smart recommendation engine',
    'sec-faq-tag':'/ FAQ','sec-faq-title':'Frequently Asked Questions','sec-faq-desc':'Everything you may want to know about QingLuan Cloud Walk',
    'sec-contact-tag':'/ Contact','sec-contact-title':'Contact Us','sec-contact-desc':'Tel 198-8859-5523 · Email 19888595523@163.com',
    'bg-stat-global':'Visually impaired worldwide','bg-stat-src':'WHO 2024 Data','bg-stat-dog':'Guide dog ratio (China)','bg-stat-period':'Guide dog training period','bg-stat-cost':'Cost per guide dog',
    'bg-pain-title':'Three Major Industry Pain Points',
    'bg-pain1-title':'Severe Supply-Demand Imbalance','bg-pain1-desc':'China has approximately 17.3 million visually impaired people, yet fewer than <strong>200 qualified guide dogs</strong> nationwide. On average, there is only 1 guide dog per 40,000 people, with waiting times of 3-5 years.','bg-pain1-quote':'"Guide dogs are rarer than giant pandas"<br>— China Association of the Blind',
    'bg-pain2-title':'Extremely High Cost Barrier','bg-pain2-desc':'Training a qualified guide dog costs approximately <strong>¥150,000-200,000</strong>, requiring 18-24 months of training, professional care, and matching. Even after approval, annual upkeep exceeds <strong>¥8,000</strong>.','bg-pain2-quote':'The industry cannot scale; costs cannot be amortized',
    'bg-pain3-title':'Inadequate Traditional Devices','bg-pain3-desc':'Existing electronic guidance devices generally suffer from three major flaws: <strong>insufficient navigation accuracy, unnatural interaction, and lack of active obstacle avoidance</strong>. Single-sensor reliability cannot meet safety requirements in complex urban environments.','bg-pain3-quote':'"It works, but not well enough"<br>— Real feedback from blind users',
    'bg-compare-title':'Why Choose QingLuan Cloud Walk?','bg-compare-dim':'Dimension','bg-compare-dog':'Guide Dog','bg-compare-stick':'Electronic Cane','bg-compare-us':'QingLuan',
    'bg-compare-cost-label':'Cost','bg-compare-dog-cost':'¥150-200K','bg-compare-stick-cost':'¥500-5,000','bg-compare-us-cost':'From ¥3,999',
    'bg-compare-supply-label':'Supply','bg-compare-dog-supply':'< 200/year','bg-compare-stick-supply':'Unlimited','bg-compare-us-supply':'Mass-producible',
    'bg-compare-avoid-label':'Obstacle Avoidance','bg-compare-dog-avoid':'✓ Natural instinct','bg-compare-stick-avoid':'✗ Distance alert only','bg-compare-us-avoid':'✓ Vision + Ultrasonic',
    'bg-compare-path-label':'Path Planning','bg-compare-dog-path':'✗ Memory training','bg-compare-stick-path':'✗ None','bg-compare-us-path':'✓ A* + Potential Field',
    'bg-compare-voice-label':'Voice Interaction','bg-compare-dog-voice':'✗ None','bg-compare-stick-voice':'✗ Simple beeps','bg-compare-us-voice':'✓ Offline AI + TTS',
    'bg-compare-maint-label':'Maintenance','bg-compare-dog-maint':'¥8,000+/year','bg-compare-stick-maint':'Low','bg-compare-us-maint':'Low (recharge only)',
    'bg-mission-p1':'We believe that <strong>technology\'s purpose is not to show off, but to solve real problems</strong>. QingLuan Cloud Walk was born from a simple idea — to give every visually impaired person an "electronic guide dog", freeing them from being trapped by cost, scarcity, and waiting.',
    'bg-mission-p2':'From the first line of bipedal walking code to the current dual-chip architecture with AI vision fusion, we have spent countless days and nights bringing technology to life — <strong>not a lab toy, but a companion on every street corner</strong>.',
    'bg-mission-vision':'Vision','bg-mission-vision-desc':'Create a smart guide robot affordable for everyone',
    'bg-mission-way':'Approach','bg-mission-way-desc':'Dual-chip · Multi-sensor fusion · Open source',
    'bg-mission-heart':'Mission','bg-mission-heart-desc':'Technology that warms lives, starting from one kilometer',
    'platform-layer-app':'Application Layer','platform-layer-app-sub':'Application Layer','platform-layer-app-1-title':'Sales Platform Frontend','platform-layer-app-1-desc':'Smart guide product showcase & transaction platform',
    'platform-layer-app-2-title':'High-Value Demand Push','platform-layer-app-2-desc':'Personalized recommendations matching user profiles',
    'platform-connector-1':'Data Flow · Intelligent Matching',
    'platform-layer-match':'Matching Layer','platform-layer-match-sub':'Matching Layer','platform-layer-match-1-title':'Information Graph Correlation','platform-layer-match-1-desc':'Dynamic knowledge graph construction and reasoning',
    'platform-layer-match-2-title':'Demand Matching Engine','platform-layer-match-2-desc':'Multi-layer fuzzy evaluation + clustering recommendation',
    'platform-connector-2':'Real-time Collection · Auto Monitoring',
    'platform-layer-collect':'Collection Layer','platform-layer-collect-sub':'Collection Layer','platform-layer-collect-1-title':'Crawler Node Management','platform-layer-collect-1-desc':'Distributed automatic information monitoring and discovery',
    'platform-layer-collect-2-title':'Demand Intelligence Collection','platform-layer-collect-2-desc':'Multi-source heterogeneous data aggregation and cleaning',
    'platform-subsys-title':'Four Subsystems',
    'platform-subsys-1-title':'Demand Intelligence Collection','platform-subsys-1-desc':'Automated crawler node management, real-time monitoring of multi-source demand data, building a comprehensive intelligence network','platform-subsys-1-t1':'Distributed Crawler','platform-subsys-1-t2':'Real-time Monitoring','platform-subsys-1-t3':'Data Aggregation',
    'platform-subsys-2-title':'Demand Cleaning & Classification','platform-subsys-2-desc':'NLP and rule-based heterogeneous data cleaning, intelligent classification and labeling, extracting high-value demand features','platform-subsys-2-t1':'NLP Processing','platform-subsys-2-t2':'Smart Classification','platform-subsys-2-t3':'Feature Extraction',
    'platform-subsys-3-title':'Value Assessment & Matching','platform-subsys-3-desc':'Multi-layer fuzzy evaluation model integrating user profiles and scenario features for precise demand-product mapping','platform-subsys-3-t1':'Fuzzy Evaluation','platform-subsys-3-t2':'User Profiling','platform-subsys-3-t3':'Precise Matching',
    'platform-subsys-4-title':'Knowledge Graph Construction','platform-subsys-4-desc':'Guide-dog domain knowledge graph based on Deep KE framework, supporting dynamic relational reasoning and semantic search','platform-subsys-4-t1':'Deep KE','platform-subsys-4-t2':'Relational Reasoning','platform-subsys-4-t3':'Semantic Search',
    'platform-config-title':'Smart Parameter Configuration','platform-config-desc':'Automatically recommends optimal product configuration based on user characteristics',
    'config-gender':'Gender','config-male':'Male','config-female':'Female',
    'config-age':'Age','config-height':'Height (cm)','config-scene':'Usage Scenario','config-scene-urban':'Urban Commute','config-scene-indoor':'Indoor Navigation','config-scene-outdoor':'Outdoor Parks','config-scene-mixed':'Mixed Scenarios',
    'config-vision':'Vision Status','config-vision-blind':'Total Blindness','config-vision-low':'Low Vision (Light Perception)','config-vision-partial':'Moderate Low Vision',
    'config-city':'City','config-city-tier1':'Tier 1 (Beijing/Shanghai/etc.)','config-city-tier2':'Tier 2 Cities','config-city-tier3':'Tier 3-4 Cities','config-city-town':'Towns/Villages',
    'config-frequency':'Travel Frequency','config-freq-daily':'Daily','config-freq-weekly':'3-5 times/week','config-freq-occasional':'Occasional (< 3/week)',
    'config-income':'Monthly Income','config-income-opt':'Optional','config-income-none':'Prefer not to say','config-income-low':'Under ¥3,000','config-income-mid':'¥3,000 – 6,000','config-income-high':'¥6,000 – 10,000','config-income-premium':'¥10,000+',
    'config-output-header':'Recommended Configuration','config-out-size':'Body Size','config-out-rope':'Rope Length','config-out-voice':'Voice Mode','config-out-speed':'Travel Speed','config-out-sense':'Obstacle Sensitivity','config-out-battery':'Battery Capacity','config-out-tier':'Recommended Tier','config-out-warranty':'Warranty',
    'platform-recommend-title':'Personalized Recommendation System',
    'platform-rec-step1-title':'Demand Prediction','platform-rec-step1-desc':'Predict potential navigation needs based on user profile and behavior history',
    'platform-rec-step2-title':'Product Matching','platform-rec-step2-desc':'Knowledge graph semantic matching + multi-layer fuzzy evaluation to select optimal products',
    'platform-rec-step3-title':'Smart Recommendation','platform-rec-step3-desc':'Personalized ranking + scenario adaptation, one-click optimal solution delivery',
    'platform-rec-btn':'🔍 Smart Recommendation',
    'platform-tech-title':'Platform Core Technology',
    'platform-tech-1-title':'Distributed Crawler Engine','platform-tech-1-desc':'Multi-node collaborative collection, intelligent anti-crawling strategies, dynamic page rendering and scheduled task scheduling',
    'platform-tech-2-title':'Deep KE Knowledge Graph','platform-tech-2-desc':'Domain-specific knowledge graph framework for guide devices, supporting entity extraction, relational reasoning, and dynamic updates',
    'platform-tech-3-title':'Clustering Recommendation','platform-tech-3-desc':'K-Means + hierarchical clustering, combining collaborative filtering and content-based recommendation for multi-dimensional matching',
    'platform-tech-4-title':'Multi-Layer Fuzzy Evaluation','platform-tech-4-desc':'Building multi-level evaluation indicator systems with fuzzy comprehensive evaluation to quantify demand-product compatibility',
    'platform-stat-1':'Dev Efficiency Boost','platform-stat-1-desc':'Tech reuse saves development time',
    'platform-stat-2':'Automated Collection','platform-stat-2-desc':'Zero manual intervention monitoring',
    'platform-stat-3':'Data Monetization','platform-stat-3-desc':'Demand data enables secondary revenue',
    'platform-stat-4':'Matching Accuracy','platform-stat-4-desc':'Multi-layer fuzzy evaluation precision',
    // Configurator output values
    'rec-size-small':'Small','rec-size-medium':'Medium','rec-size-large':'Large',
    'rec-voice-standard-male':'Standard Male','rec-voice-standard-female':'Standard Female','rec-voice-gentle-male':'Gentle Male','rec-voice-gentle-female':'Gentle Female','rec-voice-hd-male':'High-Detail Male','rec-voice-hd-female':'High-Detail Female',
    'rec-sense-standard':'Standard','rec-sense-medium':'Medium','rec-sense-high':'High','rec-sense-ultra':'Ultra',
    'rec-tier-pro':'Flagship Pro','rec-tier-plus':'Advanced Plus','rec-tier-standard':'Standard','rec-tier-lite':'Basic Lite',
    'rec-warranty-pro':'3-Year Premium','rec-warranty-plus':'2-Year Assurance','rec-warranty-basic-ext':'1-Year Basic + Ext.','rec-warranty-basic':'1-Year Basic',
    // Recommendation demo
    'rec-demo-init':'Initializing engine...','rec-demo-stage1-status':'⚙️ Engine initialized, building inference context...','rec-demo-stage1-log':'Loading Deep KE Knowledge Graph Engine v3.2\nRegistering entities: User Profile, Product Models, Scenario Features, Sensor Parameters\nInitializing fuzzy evaluation matrix (5 layers × 12 indicators)',
    'rec-demo-stage2-status':'👤 Reading user profile: ','rec-demo-stage2-log':'Age: {age} ({ageGroup})\nHeight: {height}cm\nGender: {gender}\nVision: {vision}\nCity: {city}','rec-demo-youth':'Youth','rec-demo-middle':'Middle-Aged','rec-demo-senior':'Senior',
    'rec-demo-stage3-status':'📊 Building demand feature space — Scenario: {scene}...','rec-demo-stage3-log':'Scenario: {scene}\nFrequency: {freq}\nIncome: {income}\n→ Safety Weight: {safetyWeight}\n→ {enduranceThreshold}','rec-demo-safety-high':'HIGH(+8%)','rec-demo-safety-priority':'PRIORITY(+10%)','rec-demo-safety-standard':'Standard','rec-demo-endurance-high':'Endurance ≥ 2.0h','rec-demo-endurance-normal':'Endurance ≥ 1.2h',
    'rec-demo-stage4-status':'🕸️ Knowledge graph relational reasoning...','rec-demo-stage4-log':'Entity Linking: User Profile → Association Rules (matched {ruleHits})\nRelation Reasoning: {scene} ↔ Product Compatibility Matrix\nPath Discovery: 2-hop → candidate set {catalogCount}\nScenario Match Weight: {scene} priority +{sceneBonus}%',
    'rec-demo-stage5-status':'🧠 Multi-layer fuzzy evaluation computing...','rec-demo-stage5-log':'Layer 1: Safety → w={wSafety}\nLayer 2: Comfort → Adaptive Weight\nLayer 3: Usability → Adaptive Weight\nLayer 4: Endurance → Adaptive Weight\nLayer 5: Value → {valueWeight}',
    'rec-demo-stage5-value-normal':'Standard','rec-demo-stage5-value-high':'Weight Increased (Budget-Sensitive)',
    'rec-demo-stage6-status':'📈 Cluster analysis + collaborative filtering...','rec-demo-stage6-log':'K-Means: {kMeansCluster}\nCluster: {vision}→{clusterType}\nCollaborative Filtering: Similar Users Top-K=3\nPearson Coefficient > 0.83','rec-demo-cluster-simple':'k=3 Simplified','rec-demo-cluster-normal':'k=4 Clustering','rec-demo-cluster-outdoor':'Outdoor Cluster','rec-demo-cluster-urban':'Urban Cluster','rec-demo-cluster-mixed':'Mixed Cluster',
    'rec-demo-stage7-status':'🎯 Integrated ranking + scenario adaptation...','rec-demo-stage7-log':'Normalization: Min-Max Scaling\nWeighted Fusion: Σ(λi × score_i)\nRanking: {sortStr}\nScenario Check: {topCount}/{totalCount} passed compatibility',
    'rec-demo-stage8-status':'✨ Generating personalized recommendation','rec-demo-stage8-log':'Strategy: {strategy}\nConfidence: Avg {avgScore}%\nAdoption Estimate: {adoptionRate}\n✓ Solution Ready → Top-{topCount}','rec-demo-strategy-safety':'Safety-First Strategy','rec-demo-strategy-endurance':'Endurance-First Strategy','rec-demo-strategy-balanced':'Balanced Coverage Strategy',
    'rec-demo-done':'✅ Complete — Matched {count} products based on {gender} {age}yr {scene}','rec-demo-done-suffix':'✓ Inference complete, ~4.6s',
    'rec-demo-progress-label':'Inference Progress',
    'faq-q1':'How is QingLuan different from a guide dog?','faq-a1':'Guide dogs require 18-24 months of training, cost ¥150,000-200,000, number fewer than 200 nationwide, with waiting times of 3-5 years. QingLuan is mass-producible, available immediately, starting at ¥3,999, and features <strong>A* path planning, AI vision obstacle avoidance, and voice navigation</strong> — capabilities guide dogs lack.',
    'faq-q2':'How long does the battery last? Is it easy to charge?','faq-a2':'The standard version has a 5000mAh battery with <strong>~1.5 hours / 5-8 km</strong> of full-function range. The Pro version upgrades to 8000mAh with <strong>~2.5 hours / 12 km</strong>. USB-C fast charging — full charge in 2 hours; any power bank works for emergencies.',
    'faq-q3':'How is safety ensured?','faq-a3':'Three independent safety mechanisms: <strong>① Communication watchdog</strong> (auto-stop after 1000ms timeout), <strong>② IMU fall detection</strong> (emergency power cut at >45° tilt), <strong>③ Force sensor emergency stop</strong> (reverse braking at >20N push force). Any single trigger activates safe mode — redundant by design.',
    'faq-q4':'What is the warranty and after-sales policy?','faq-a4':'Lite version includes <strong>1-year basic warranty</strong>, Plus version includes <strong>2-year peace-of-mind warranty</strong>, Pro version includes <strong>3-year premium warranty</strong>. All products come with free nationwide shipping and 7-day no-questions-asked returns. Customer service: 198-8859-5523, weekdays 9:00-18:00.',
    'faq-q5':'Can it be used outdoors in the rain?','faq-a5':'The device has <strong>IP54 water and dust resistance</strong>, suitable for light rain and splashes, but not recommended for heavy rain or standing water. Ultrasonic sensors work normally in rain; the visual camera automatically lowers confidence thresholds and relies more on ultrasonic ranging in rainy/foggy conditions.',
    'faq-q6':'How does it adapt to users of different heights?','faq-a6':'Adjustable rope length (110cm / 120cm / 135cm), adaptive leg height (70-130mm). The smart parameter panel automatically recommends the optimal configuration based on gender, age, and height. The 5-bar parallel mechanism self-balances throughout — no manual calibration needed.',
    'md-home': "**QingLuan Cloud Walk Smart Guide Robot** — a safe, reliable, and intelligent mobility companion for the visually impaired.\n\n---\n\n### Core Values\n\n- **Safe & Reliable** — Multi-sensor fusion + redundant safety architecture, millisecond emergency response\n- **Intelligent Navigation** — A* global path planning + artificial potential field local obstacle avoidance, autonomous traversal of complex environments\n- **Natural Interaction** — Multi-axis force sensor following + offline AI voice commands, seamless human-robot collaboration\n- **Always-On Protection** — Fall detection, watchdog protection, emergency braking — triple safety protection\n\n### Technical Highlights\n\n| System | Technology | Specification |\n|------|------|------|\n| Perception | FOMO Object Detection | 10Hz frame rate, 30ms inference |\n| Planning | A* + Potential Field | 100×100 grid, 8-direction paths |\n| Control | Cascade PID + 5-bar Inverse Kinematics | 50-200Hz control frequency |\n| Interaction | Admittance Control + Offline ASR | 20 commands, >92% recognition rate |\n| Safety | Watchdog + IMU Fall Detection | 1000ms timeout shutdown |\n\n> Technology is not cold code — it is the power that warms the human heart.",
    'md-about': "### Our Mission\n\nWe are dedicated to creating independent, confident mobility experiences for the visually impaired through advanced robotics and AI. Every line of code, every algorithm points to the same vision — **letting technology warm lives**.\n\n### Project Background\n\nThis product was born from deep insight into real social needs. There are over 285 million visually impaired people worldwide. Traditional guide dogs require 18-24 months of training, cost approximately ¥150,000-200,000, and are extremely scarce. Meanwhile, electronic guidance devices have never reached practical usability in complex environments.\n\nWe built a truly usable smart guide robot with the **ESP32-S3 + OpenMV H7 Plus dual-chip** architecture, integrating computer vision, path planning, motion control, and voice interaction.\n\n### R&D Team\n\n- **Hardware** — ESP32-S3 motion control + OpenMV H7 Plus vision planning\n- **Perception** — FOMO object detection + distortion correction + ultrasonic ranging fusion\n- **Motion Control** — Cascade PID + 5-bar inverse kinematics + BLDC FOC\n- **HCI** — Admittance control force-following + offline AI voice + TTS\n- **System Integration** — Multi-sensor fusion + communication protocols + safety architecture\n\n### Development History\n\n| Phase | Period | Milestone |\n|------|------|--------|\n| V1 | Early | Bipedal walking + basic PID control |\n| V2 | Mid | Ultrasonic obstacle avoidance + heading recovery |\n| V3 | Current | A* global planning + FOMO vision + dual-chip architecture |\n\n### Open Source Spirit\n\nThe project is fully open source. We welcome developer contributions and improvements. We believe open collaboration accelerates technological progress, allowing more people to benefit from assistive technology.",
    'md-products': "### Hardware Platform\n\n| Component | Model | Description |\n|------|------|------|\n| Motion Control MCU | ESP32-S3 DevKitC-1 | 240MHz dual-core Xtensa LX7 |\n| Vision/Planning MCU | OpenMV H7 Plus | Cortex-M7 @ 480MHz, 32MB SDRAM |\n| IMU Sensor | MPU6050 | I2C interface, 400kHz |\n| Ultrasonic Ranging | High-precision module | Temperature-compensated, ±0.5cm accuracy |\n| Vision Sensor | OV5640 | QVGA, FOMO object detection |\n| Scanning Gimbal | Pan servo | Ultrasonic + OpenMV co-mounted |\n| Leg Actuators | MG996R Servo × 4 | PCA9685 PWM driver |\n| Drive Actuators | BLDC Hub Motors × 2 | FOC vector control |\n| HCI | Multi-axis force sensor + Offline ASR | Admittance control + voice |\n| Power | 3S 5000mAh LiPo | ~1.5h full-function runtime |\n\n### System Architecture\n\n```\n┌────────────────────────────────────────────┐\n│ OpenMV H7 Plus (10Hz Perception & Planning) │\n│ Vision → A* Planning → Ultrasonic → Avoidance│\n└────────────────┬───────────────────────────┘\n                 │ UART @ 921600 bps\n┌────────────────┴───────────────────────────┐\n│ ESP32-S3 (50-200Hz Motion Control)          │\n│ PID → Inverse Kinematics → Servo/Motor → ASR│\n└────────────────────────────────────────────┘\n```\n\n### Technical Specifications\n\n| Metric | Value |\n|------|------|\n| System Frame Rate | 10Hz (perception+planning+control) |\n| Control Frequency | 50-200Hz (PID + motors) |\n| Obstacle Localization | Lateral ±7cm, Forward ±2cm @1m |\n| Ultrasonic Accuracy | ±0.5cm (temperature-compensated) |\n| Max Speed | 0.5m/s |\n| Leg Height Range | 70-130mm (adaptive) |\n| Turning Mode | Zero-radius spot turning |\n| Hardware Cost | Scalable production, far below guide dogs |\n\n### Core Capabilities\n\n**Perception Layer** — FOMO object detection model, ~30ms inference, fused ultrasonic precise ranging, dual-channel redundant obstacle avoidance\n\n**Planning Layer** — A* global path planning (100×100 grid, 8-direction), artificial potential field local obstacle avoidance\n\n**Control Layer** — Cascade PID (speed+balance+steering loops), 5-bar inverse kinematics, FOC hub motor drive\n\n**Interaction Layer** — Admittance control force-following, offline AI speech recognition (20 commands, >92% accuracy), TTS voice feedback, WiFi WebSocket remote monitoring",
    'md-technology': "### Dual-Chip Architecture\n\nOpenMV H7 Plus handles upstream perception and path planning. ESP32-S3 handles downstream motion control and HCI. The two chips communicate via UART @ 921600 bps, with critical data loops closed within each chip.\n\n**Design Advantage:** Perception and control are decoupled. OpenMV's 32MB SDRAM satisfies vision inference memory demands; ESP32-S3's dedicated processor guarantees real-time control.\n\n### Visual Perception — FOMO Object Detection\n\nTensorFlow Lite Micro deploys a FOMO (Faster Objects, More Objects) model:\n\n| Item | Parameter |\n|------|------|\n| Input | QVGA 240×240, RGB565 |\n| Classes | Chair, pillar, hand + background |\n| Confidence | ≥ 0.5 |\n| Inference | ~30ms/frame |\n| Output Map | 30×30 (8× downsampled) |\n\nWith OV5640 distortion correction (residual < 0.1°), visual localization accuracy meets real-world navigation requirements.\n\n### A* Global Path Planning\n\n100×100 grid map covering a 10×10m area, 8-direction neighborhood search + Euclidean distance heuristic, single planning takes 20-50ms:\n\n```\nf(n) = g(n) + h(n)\ng(n): actual cost from start to current node\nh(n): Euclidean distance estimate to goal\n```\n\nPath tracking takes the 3rd-5th grid ahead as the local target, with direction as attractive force input to the potential field.\n\n### Artificial Potential Field Local Obstacle Avoidance\n\n```\nU_total(q) = U_att(q) + U_rep(q)\nF(q) = -∇U(q)\n```\n\nAttractive force points toward A* local target; repulsive force comes from obstacle directions. The resultant force determines left/right wheel avoidance factors. The dual-wheel zero-radius turning capability enables \"turn-then-go\" execution, better aligned with potential field gradient than traditional \"turn-while-going\".\n\n### Cascade PID Control Architecture\n\nFour-loop cascade: Speed (P) → Balance (PD) → Steering (P) → Height (P)\n\n**Key Design:** The balance loop uses PD rather than PID — integral terms introduce phase lag in inverted pendulum control, reducing stability. PD's proportional term provides restoring force; derivative term provides damping.\n\nPID parameters adapt with leg height (70-130mm), smoothly interpolated via quadratic functions.\n\n### 5-Bar Parallel Inverse Kinematics\n\nA closed-chain 5-bar parallel mechanism provides higher stiffness and load capacity compared to traditional serial legs:\n\n| Comparison | Serial Leg | 5-Bar Parallel |\n|--------|--------|-----------|\n| Stiffness | Low (cantilevered) | High (triangulated) |\n| Load Capacity | Low | High (suitable for heavy-duty guidance) |\n| Servo Load | Large | Small (force shared by linkages) |\n\n### Safety Architecture\n\n```\nCondition 1: >300ms no OpenMV frame → decelerate to zero\nCondition 2: >1000ms no OpenMV frame → motors zero, servos lock\nCondition 3: Pitch > 45° (fall detected) → emergency power cut\nCondition 4: Push force > 20N (emergency stop intent) → reverse brake 200ms\n```\n\nThree independent safety mechanisms: communication watchdog + IMU fall detection + force sensor emergency stop. Any single trigger activates safe mode.\n\n### Interaction Technology\n\n- **Admittance Control:** F_push / D_viscous → target velocity, 0.5N-20N linear mapping\n- **Offline ASR:** ESP-SR framework, 20 navigation command words, >92% recognition in quiet environments\n- **TTS Feedback:** Obstacle alerts, low battery warnings, command confirmations, pre-synthesized audio\n- **WebSocket Monitoring:** 1Hz JSON status broadcast, mobile browser real-time dashboard",
    'md-contact': "We look forward to collaborating with you to advance assistive technology.\n\n---\n\n### Contact Information\n\n- **Email:** 19888595523@163.com\n- **Phone:** 198-8859-5523\n- **GitHub:** [github.com/QingLuan](https://github.com)\n- **Open Source:** All source code is public. Contributions and feedback are welcome.\n\n### Collaboration\n\n- **Technical:** Sensor fusion, path planning, motion control algorithm research\n- **Application:** Guide robot pilot deployment, scenario adaptation development\n- **Academic:** Paper citations, experimental data sharing, joint research proposals\n- **Community:** Code contributions, documentation, testing and validation\n\n### Join Us\n\nIf you are passionate about robotics, computer vision, or human-computer interaction, welcome to our open source community.\n\n**We are looking for:**\n\n- Embedded Systems Engineers (ESP32/STM32)\n- Computer Vision Algorithm Engineers\n- Motion Control & Robotics Researchers\n- Product Design & UX Specialists\n\n---\n\n> QingLuan spreads its wings, walking the world with cloud steps — we are always on the road."
  }
};

function initLanguageSwitch() {
  const toggle = document.getElementById('lang-toggle');
  if (!toggle) return;

  const saved = localStorage.getItem('qingluan-lang') || 'zh';
  let currentLang = saved;
  applyLanguage(currentLang);

  toggle.addEventListener('click', () => {
    currentLang = currentLang === 'zh' ? 'en' : 'zh';
    localStorage.setItem('qingluan-lang', currentLang);
    applyLanguage(currentLang);
  });

  function applyLanguage(lang) {
    document.documentElement.setAttribute('lang', lang === 'zh' ? 'zh-CN' : 'en');
    const dict = I18N[lang];
    const en = lang === 'en';

    // ── Helpers ──
    const t = (sel, key) => { const el = document.querySelector(sel); if (el && dict[key]) el.textContent = dict[key]; };
    const h = (sel, key) => { const el = document.querySelector(sel); if (el && dict[key]) el.innerHTML = dict[key]; };
    const ta = (sel, key) => { const el = document.querySelector(sel); if (el) el.setAttribute('title', dict[key]); };
    const all = (sel, keyFn) => { document.querySelectorAll(sel).forEach((el, i) => { const k = keyFn(i); if (dict[k]) el.textContent = dict[k]; }); };

    // ── UI chrome ──
    toggle.querySelector('span').textContent = en ? '中' : 'EN';
    ta('#lang-toggle', 'lang-title'); ta('#a11y-toggle', 'a11y-title'); ta('#search-toggle', 'search-title'); ta('#back-to-top', 'back-top');
    all('.nav-links a', i => ['nav-home','nav-bg','nav-about','nav-products','nav-tech','nav-platform','nav-faq','nav-contact'][i]);
    t('.hero-badge', 'hero-badge'); h('.hero-subtitle', 'hero-subtitle'); h('.hero-actions .btn-primary', 'hero-btn1'); t('.hero-actions .btn-outline', 'hero-btn2'); t('.hero-scroll-indicator span', 'hero-scroll');
    t('.theme-panel-label', 'theme-label'); h('.footer-text', 'footer-text');
    t('.cta-text', 'cta-text'); h('.cta-btn', 'cta-btn');
    const si = document.getElementById('search-input'); if (si) si.placeholder = dict['search-placeholder'];
    const sh = document.querySelector('.search-hint'); if (sh) sh.textContent = dict['search-hint'];
    const rp = document.querySelector('.rec-phase-label'); if (rp) rp.textContent = dict['rec-demo-progress-label'];

    // ── Section headers ──
    [{id:'home-intro',k:'home'},{id:'background',k:'bg'},{id:'about',k:'about'},{id:'products',k:'products'},{id:'technology',k:'tech'},{id:'platform',k:'platform'},{id:'faq',k:'faq'},{id:'contact',k:'contact'}].forEach(({id,k}) => {
      const sec = document.getElementById(id); if (!sec) return;
      const tag = sec.querySelector('.section-tag'); if (tag && dict['sec-'+k+'-tag']) tag.textContent = dict['sec-'+k+'-tag'];
      const title = sec.querySelector('.section-title'); if (title && dict['sec-'+k+'-title']) title.textContent = dict['sec-'+k+'-title'];
      const desc = sec.querySelector('.section-desc'); if (desc && dict['sec-'+k+'-desc']) desc.textContent = dict['sec-'+k+'-desc'];
    });

    // ── Background: stats ──
    h('.bg-stat-hero-label', 'bg-stat-global'); h('.bg-stat-hero-src', 'bg-stat-src');
    const mls = document.querySelectorAll('.bg-stat-mini-label');
    if (mls[0]) mls[0].textContent = dict['bg-stat-dog'];
    if (mls[1]) mls[1].textContent = dict['bg-stat-period'];
    if (mls[2]) mls[2].textContent = dict['bg-stat-cost'];
    const bgh3 = document.querySelectorAll('#background .md-content h3');
    if (bgh3[0]) bgh3[0].textContent = dict['bg-pain-title'];
    if (bgh3[1]) bgh3[1].textContent = dict['bg-compare-title'];

    // ── Background: pain cards ──
    ['bg-pain1','bg-pain2','bg-pain3'].forEach((k,i) => {
      const card = document.querySelectorAll('.pain-card')[i]; if (!card) return;
      const h4 = card.querySelector('h4'); if (h4) h4.textContent = dict[k+'-title'];
      const p = card.querySelector('p'); if (p) p.innerHTML = dict[k+'-desc'];
      const q = card.querySelector('.pain-quote'); if (q) q.innerHTML = dict[k+'-quote'];
    });

    // ── Background: compare table ──
    ['dim','dog','stick'].forEach((k,i) => {
      const span = document.querySelector('.bg-compare-header span:nth-child('+(i+1)+')');
      if (span) span.textContent = dict['bg-compare-'+k];
    });
    const rows = document.querySelectorAll('.bg-compare-row');
    ['cost','supply','avoid','path','voice','maint'].forEach((rk, ri) => {
      const row = rows[ri]; if (!row) return;
      const cells = row.querySelectorAll('span');
      if (cells[0]) cells[0].textContent = dict['bg-compare-'+rk+'-label'];
      ['dog','stick','us'].forEach((sk, si) => {
        if (cells[si+1]) cells[si+1].innerHTML = dict['bg-compare-'+sk+'-'+rk];
      });
    });

    // ── Background: mission ──
    const mps = document.querySelectorAll('.bg-mission-text p');
    if (mps[0]) mps[0].innerHTML = dict['bg-mission-p1'];
    if (mps[1]) mps[1].innerHTML = dict['bg-mission-p2'];
    ['vision','way','heart'].forEach((k,i) => {
      const card = document.querySelectorAll('.bg-mission-card')[i]; if (!card) return;
      const strong = card.querySelector('strong'); if (strong) strong.innerHTML = dict['bg-mission-'+k];
      const p = card.querySelector('p'); if (p) p.textContent = dict['bg-mission-'+k+'-desc'];
    });

    // ── Platform: section headings ──
    document.querySelectorAll('#platform .md-content > h3, #platform h3').forEach(h3 => {
      const t = h3.textContent;
      if (t.includes('子系统') || t.includes('Subsystem')) h3.textContent = dict['platform-subsys-title'];
      else if (t.includes('智能参数') || t.includes('Parameter')) h3.textContent = dict['platform-config-title'];
      else if (t.includes('个性化推荐') || t.includes('Recommendation')) h3.textContent = dict['platform-recommend-title'];
      else if (t.includes('平台核心') || t.includes('Core Technology')) h3.textContent = dict['platform-tech-title'];
    });
    t('.config-desc', 'platform-config-desc');

    // ── Platform: layer badges & subs ──
    ['platform-layer-app','platform-layer-match','platform-layer-collect'].forEach((k,i) => {
      const badge = document.querySelectorAll('.layer-badge')[i]; if (badge) badge.textContent = dict[k];
      const sub = document.querySelectorAll('.layer-sub')[i]; if (sub) sub.textContent = dict[k+'-sub'];
    });
    const cl = document.querySelectorAll('.connector-label');
    if (cl[0]) cl[0].textContent = dict['platform-connector-1'];
    if (cl[1]) cl[1].textContent = dict['platform-connector-2'];

    // ── Platform: layer features ──
    const lfKeys = ['platform-layer-app-1-title','platform-layer-app-2-title','platform-layer-match-1-title','platform-layer-match-2-title','platform-layer-collect-1-title','platform-layer-collect-2-title'];
    const ldKeys = ['platform-layer-app-1-desc','platform-layer-app-2-desc','platform-layer-match-1-desc','platform-layer-match-2-desc','platform-layer-collect-1-desc','platform-layer-collect-2-desc'];
    document.querySelectorAll('.layer-text strong').forEach((el,i) => { if (dict[lfKeys[i]]) el.textContent = dict[lfKeys[i]]; });
    document.querySelectorAll('.layer-text span').forEach((el,i) => { if (dict[ldKeys[i]]) el.textContent = dict[ldKeys[i]]; });

    // ── Platform: subsystem cards ──
    document.querySelectorAll('.subsystem-card').forEach((card, i) => {
      const n = i+1;
      const h4 = card.querySelector('h4'); if (h4 && dict['platform-subsys-'+n+'-title']) h4.textContent = dict['platform-subsys-'+n+'-title'];
      const p = card.querySelector('p'); if (p && dict['platform-subsys-'+n+'-desc']) p.textContent = dict['platform-subsys-'+n+'-desc'];
      card.querySelectorAll('.subsystem-tags span').forEach((tag, j) => {
        const k = 'platform-subsys-'+n+'-t'+(j+1);
        if (dict[k]) tag.textContent = dict[k];
      });
    });

    // ── Platform: tech cards ──
    document.querySelectorAll('.web-tech-card').forEach((card, i) => {
      const h4 = card.querySelector('h4'); if (h4 && dict['platform-tech-'+(i+1)+'-title']) h4.textContent = dict['platform-tech-'+(i+1)+'-title'];
      const p = card.querySelector('p'); if (p && dict['platform-tech-'+(i+1)+'-desc']) p.textContent = dict['platform-tech-'+(i+1)+'-desc'];
    });

    // ── Platform: stat cards ──
    document.querySelectorAll('.pstat-label').forEach((el, i) => { if (dict['platform-stat-'+(i+1)]) el.textContent = dict['platform-stat-'+(i+1)]; });
    document.querySelectorAll('.pstat-desc').forEach((el, i) => { if (dict['platform-stat-'+(i+1)+'-desc']) el.textContent = dict['platform-stat-'+(i+1)+'-desc']; });

    // ── Platform: recommend flow steps ──
    document.querySelectorAll('.rec-step-content').forEach((step, i) => {
      const h4 = step.querySelector('h4'); if (h4 && dict['platform-rec-step'+(i+1)+'-title']) h4.innerHTML = dict['platform-rec-step'+(i+1)+'-title'];
      const p = step.querySelector('p'); if (p && dict['platform-rec-step'+(i+1)+'-desc']) p.textContent = dict['platform-rec-step'+(i+1)+'-desc'];
    });
    const rtb = document.getElementById('rec-trigger'); if (rtb && dict['platform-rec-btn']) rtb.innerHTML = dict['platform-rec-btn'];

    // ── Configurator labels ──
    const labelMap = {'config-age':'config-age','config-height':'config-height','config-scene':'config-scene','config-vision':'config-vision','config-city':'config-city','config-frequency':'config-frequency','config-income':'config-income'};
    document.querySelectorAll('.config-group > label').forEach(label => {
      const fa = label.getAttribute('for'); const k = labelMap[fa];
      if (k && label.firstChild && label.firstChild.nodeType === 3) label.firstChild.textContent = dict[k];
    });
    document.querySelectorAll('.config-radio').forEach(label => {
      const input = label.querySelector('input[name="gender"]');
      if (input && label.lastChild && label.lastChild.nodeType === 3)
        label.lastChild.textContent = ' ' + (input.value === 'male' ? dict['config-male'] : dict['config-female']);
    });
    const ot = document.querySelector('.optional-tag'); if (ot) ot.textContent = dict['config-income-opt'];

    // ── Configurator output labels ──
    h('.config-output-header strong', 'config-output-header');
    ['config-out-size','config-out-rope','config-out-voice','config-out-speed','config-out-sense','config-out-battery','config-out-tier','config-out-warranty'].forEach((k,i) => {
      const el = document.querySelector('.output-item:nth-child('+(i+1)+') .output-label');
      if (el && dict[k]) el.textContent = dict[k];
    });

    // ── FAQ ──
    document.querySelectorAll('.faq-item').forEach((item, i) => {
      const q = item.querySelector('.faq-question span'); if (q && dict['faq-q'+(i+1)]) q.innerHTML = dict['faq-q'+(i+1)];
      const a = item.querySelector('.faq-answer p'); if (a && dict['faq-a'+(i+1)]) a.innerHTML = dict['faq-a'+(i+1)];
    });

    // ── Search / Footer ──
    const sn = document.querySelector('.search-no-results'); if (sn) sn.textContent = dict['search-no'];

    // ── Select options ──
    translateAllSelectOptions();

    // ── Dynamic content ──
    reloadMarkdownForLanguage(lang);
    setTimeout(refreshConfiguratorForLanguage, 300);
  }

  function translateAllSelectOptions() {
    // Robust option translation — walks <select> children directly
    const translations = {
      'config-scene': {
        urban: ['城市通勤','Urban Commute'], indoor: ['室内导航','Indoor Navigation'],
        outdoor: ['户外公园','Outdoor Parks'], mixed: ['混合场景','Mixed Scenarios']
      },
      'config-vision': {
        blind: ['全盲 (无光感)','Total Blindness'], low: ['低视力 (光感/手动)','Low Vision'],
        partial: ['中度弱视 (指数/0.05)','Moderate Low Vision']
      },
      'config-city': {
        tier1: ['一线城市 (北上广深)','Tier 1 (Beijing/Shanghai/etc.)'],
        tier2: ['二线城市','Tier 2 Cities'],
        tier3: ['三四线城市','Tier 3-4 Cities'],
        town: ['县镇 / 乡村','Towns / Villages']
      },
      'config-frequency': {
        daily: ['每天出行','Daily'], weekly: ['每周 3-5 次','3-5 Times/Week'],
        occasional: ['偶尔出行 (每周 < 3 次)','Occasional (< 3/Week)']
      },
      'config-income': {
        '': ['不透露','Prefer not to say'], low: ['3,000 元以下','Under ¥3,000'],
        mid: ['3,000 – 6,000 元','¥3,000 – 6,000'], high: ['6,000 – 10,000 元','¥6,000 – 10,000'],
        premium: ['10,000 元以上','¥10,000+']
      }
    };
    const en = isEn();
    Object.entries(translations).forEach(([selectId, opts]) => {
      const select = document.getElementById(selectId);
      if (!select) return;
      for (let i = 0; i < select.options.length; i++) {
        const opt = select.options[i];
        const pair = opts[opt.value];
        if (pair) opt.textContent = en ? pair[1] : pair[0];
      }
    });
  }
}

// ============================================
// 15. Theme Switcher UI
// ============================================
function initThemeSwitcher() {
  ThemeManager.init();

  const switcher = document.getElementById('theme-switcher');
  const toggleBtn = document.getElementById('theme-toggle-btn');
  const panel = document.getElementById('theme-panel');
  const options = document.querySelectorAll('.theme-option');

  if (!switcher || !toggleBtn || !panel) return;

  // Toggle panel
  toggleBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    switcher.classList.toggle('open');
  });

  // Close panel when clicking outside
  document.addEventListener('click', () => {
    switcher.classList.remove('open');
  });

  panel.addEventListener('click', (e) => {
    e.stopPropagation();
  });

  // Handle theme selection
  options.forEach(opt => {
    opt.addEventListener('click', () => {
      const theme = opt.dataset.theme;
      ThemeManager.set(theme);

      // Update active markers
      options.forEach(o => o.classList.remove('active'));
      opt.classList.add('active');

      // Close panel
      switcher.classList.remove('open');

      // Reload particle colors
      if (window.__particleReload) {
        window.__particleReload(ThemeManager.getConfig());
      }
    });
  });

  // Set initial active state
  const currentTheme = ThemeManager.get();
  options.forEach(o => {
    o.classList.toggle('active', o.dataset.theme === currentTheme);
  });
}

// ============================================
// Utility: Escape HTML
// ============================================
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// I18N shorthand
function i18n(key) {
  const lang = document.documentElement.getAttribute('lang') === 'en' ? 'en' : 'zh';
  return (I18N[lang] && I18N[lang][key]) ? I18N[lang][key] : (I18N['zh'][key] || key);
}
function isEn() { return document.documentElement.getAttribute('lang') === 'en'; }

// Re-trigger configurator on language change
function refreshConfiguratorForLanguage() {
  const ageSlider = document.getElementById('config-age');
  if (ageSlider) ageSlider.dispatchEvent(new Event('input', { bubbles: true }));
}

// --- Wire up DOMContentLoaded for platform features ---
document.addEventListener('DOMContentLoaded', () => {
  initConfigurator();
  initRecommendationDemo();
  initKnowledgeGraphAnimation();
  initPlatformParallax();
});
